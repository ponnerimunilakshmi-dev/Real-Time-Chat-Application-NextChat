import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export const AuthProvider = ({ children }) => {

  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('nexchat_token');
    const savedUser = localStorage.getItem('nexchat_user');

    if (token && savedUser) {
      setUser(JSON.parse(savedUser));
      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }

    setLoading(false);
  }, []);

  const login = async (phone, password) => {
    const res = await axios.post(`${API}/auth/login`, { phone, password });
    const { token, user } = res.data;

    localStorage.setItem('nexchat_token', token);
    localStorage.setItem('nexchat_user', JSON.stringify(user));

    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    setUser(user);

    return user;
  };

  const loginWithOTP = async (phone, otp) => {
    const res = await axios.post(`${API}/auth/login-otp`, { phone, otp });
    const { token, user } = res.data;

    localStorage.setItem('nexchat_token', token);
    localStorage.setItem('nexchat_user', JSON.stringify(user));

    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    setUser(user);

    return user;
  };

  const register = async (name, phone, password) => {
    const res = await axios.post(`${API}/auth/register`, { name, phone, password });
    const { token, user } = res.data;

    localStorage.setItem('nexchat_token', token);
    localStorage.setItem('nexchat_user', JSON.stringify(user));

    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    setUser(user);

    return user;
  };

  // ✅ Correct updateUser
  const updateUser = (updatedUser) => {
    const newUser = { ...user, ...updatedUser };
    setUser(newUser);
    localStorage.setItem('nexchat_user', JSON.stringify(newUser));
  };

  const logout = () => {
    localStorage.removeItem('nexchat_token');
    localStorage.removeItem('nexchat_user');

    delete axios.defaults.headers.common['Authorization'];

    setUser(null);
  };

  const sendOTP = async (phone) => {
    const res = await axios.post(`${API}/auth/send-otp`, { phone });
    return res.data;
  };

  const verifyOTP = async (phone, otp) => {
    const res = await axios.post(`${API}/auth/verify-otp`, { phone, otp });
    return res.data;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        loginWithOTP,
        register,
        logout,
        updateUser,
        sendOTP,
        verifyOTP,
        loading
      }}
    >
      {!loading && children}
    </AuthContext.Provider>
  );
};