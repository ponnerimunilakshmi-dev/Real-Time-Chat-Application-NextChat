import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';
import { useAuth } from './AuthContext';
import { useSocket } from './SocketContext';
import { getContactSettings, NOTIFICATION_SOUNDS, playPreviewSound } from '../components/modals/ContactSettingsModal';

function playNotificationSound(contactId) {
  try {
    const settings = getContactSettings(contactId);
    if (!settings.notifEnabled) return;
    playPreviewSound(settings.sound || 'default');
  } catch {}
}

const ChatContext = createContext();
export const useChat = () => useContext(ChatContext);
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export const ChatProvider = ({ children }) => {
  const { user } = useAuth();
  const { socket } = useSocket();

  const [contacts, setContacts] = useState([]);
  const [groups, setGroups] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState({});     // { chatId: [msg...] }
  const [archivedIds, setArchivedIds] = useState(() => JSON.parse(localStorage.getItem('nc_archived') || '[]'));
  const [pinnedIds, setPinnedIds] = useState(() => JSON.parse(localStorage.getItem('nc_pinned') || '[]'));
  const [mutedIds, setMutedIds] = useState(() => JSON.parse(localStorage.getItem('nc_muted') || '[]'));
  const [starredMsgs, setStarredMsgs] = useState([]);
  const [scheduledMsgs, setScheduledMsgs] = useState([]);
  const [unreadCounts, setUnreadCounts] = useState({});
  const [typingUsers, setTypingUsers] = useState({});

  const activeChatRef = useRef(activeChat);
  useEffect(() => { activeChatRef.current = activeChat; }, [activeChat]);

  // Persist local prefs
  useEffect(() => { localStorage.setItem('nc_archived', JSON.stringify(archivedIds)); }, [archivedIds]);
  useEffect(() => { localStorage.setItem('nc_pinned', JSON.stringify(pinnedIds)); }, [pinnedIds]);
  useEffect(() => { localStorage.setItem('nc_muted', JSON.stringify(mutedIds)); }, [mutedIds]);

  const loadContacts = useCallback(async () => {
    try {
      const [cRes, gRes] = await Promise.all([
        axios.get(`${API}/users/contacts`),
        axios.get(`${API}/groups`)
      ]);
      setContacts(cRes.data);
      setGroups(gRes.data);
    } catch (e) { console.warn(e.message); }
  }, []);

  useEffect(() => { if (user) loadContacts(); }, [user, loadContacts]);

  const loadMessages = useCallback(async (chatId, chatType) => {
    try {
      const url = chatType === 'group'
        ? `${API}/messages/${chatId}?chatType=group`
        : `${API}/messages/${chatId}`;
      const res = await axios.get(url);
      setMessages(prev => ({ ...prev, [chatId]: res.data }));
      return res.data;
    } catch (e) { return []; }
  }, []);

  const openChat = useCallback(async (item, type) => {
    const chat = { ...item, chatType: type };
    setActiveChat(chat);
    const id = item._id;
    if (!messages[id] || messages[id].length === 0) {
      await loadMessages(id, type);
    }
    // Mark as read
    setUnreadCounts(prev => ({ ...prev, [id]: 0 }));
  }, [messages, loadMessages]);

  // ── Socket events ─────────────────────────────────────────
  useEffect(() => {
    if (!socket) return;

    socket.on('message:receive', (msg) => {
      const cid = msg.group || msg.sender?._id || msg.sender;
      const currentChat = activeChatRef.current;
      setMessages(prev => {
        const list = prev[cid] || [];
        if (list.find(m => m._id === msg._id)) return prev;
        return { ...prev, [cid]: [...list, msg] };
      });
      if (!currentChat || currentChat._id !== cid) {
        setUnreadCounts(prev => ({ ...prev, [cid]: (prev[cid] || 0) + 1 }));
        // Play per-contact notification sound
        playNotificationSound(cid);
        // Show browser notification if permission granted
        if (Notification.permission === 'granted') {
          const settings = getContactSettings(cid);
          if (settings.notifEnabled) {
            const sender = msg.sender?.name || 'New message';
            const body = settings.notifPreview ? (msg.content || '📷 Media') : 'New message';
            new Notification(sender, { body, icon: msg.sender?.avatar || undefined, silent: true });
          }
        }
      } else {
        socket.emit('message:read', { messageId: msg._id, senderId: cid });
      }
    });

    socket.on('message:sent', (msg) => {
      const cid = msg.group || msg.receiver;
      setMessages(prev => {
        const list = prev[cid] || [];
        const filtered = list.filter(m => m._id !== msg.tempId);
        if (filtered.find(m => m._id === msg._id)) return { ...prev, [cid]: filtered };
        return { ...prev, [cid]: [...filtered, msg] };
      });
    });

    socket.on('message:edited', ({ messageId, content }) => {
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => {
          updated[cid] = prev[cid].map(m =>
            m._id === messageId ? { ...m, content, isEdited: true } : m
          );
        });
        return updated;
      });
    });

    socket.on('message:reacted', ({ messageId, reactions }) => {
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => {
          updated[cid] = prev[cid].map(m =>
            m._id === messageId ? { ...m, reactions } : m
          );
        });
        return updated;
      });
    });

    socket.on('message:deleted', ({ messageId, deleteType }) => {
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => {
          updated[cid] = prev[cid].map(m => {
            if (m._id !== messageId) return m;
            if (deleteType === 'everyone') return { ...m, deletedForEveryone: true, content: 'This message was deleted', mediaUrl: '' };
            return { ...m, deletedForMe: true };
          }).filter(m => !m.deletedForMe);
        });
        return updated;
      });
    });

    socket.on('message:starred', ({ messageId, starred }) => {
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => {
          updated[cid] = prev[cid].map(m =>
            m._id === messageId ? { ...m, isStarred: starred } : m
          );
        });
        return updated;
      });
    });

    socket.on('message:read', ({ messageId }) => {
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => {
          updated[cid] = prev[cid].map(m =>
            m._id === messageId ? { ...m, read: true } : m
          );
        });
        return updated;
      });
    });

    socket.on('poll:updated', ({ messageId, poll }) => {
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => {
          updated[cid] = prev[cid].map(m =>
            m._id === messageId ? { ...m, poll } : m
          );
        });
        return updated;
      });
    });

    socket.on('message:scheduled', (msg) => {
      setScheduledMsgs(prev => [...prev, msg]);
    });

    socket.on('typing:start', ({ from }) => setTypingUsers(prev => ({ ...prev, [from]: true })));
    socket.on('typing:stop',  ({ from }) => setTypingUsers(prev => { const n={...prev}; delete n[from]; return n; }));

    return () => {
      ['message:receive','message:sent','message:edited','message:reacted','message:deleted',
       'message:starred','message:read','poll:updated','message:scheduled',
       'typing:start','typing:stop'].forEach(e => socket.off(e));
    };
  }, [socket]);

  const sendMessage = useCallback((payload) => {
    if (!socket || !activeChat) return;
    const tempId = 'temp_' + Date.now();
    const cid = activeChat._id;
    const optimistic = {
      _id: tempId, tempId,
      sender: user,
      createdAt: new Date().toISOString(),
      readBy: [], reactions: [],
      ...payload,
      receiver: activeChat.chatType === 'user' ? cid : undefined,
      group: activeChat.chatType === 'group' ? cid : undefined,
    };
    setMessages(prev => ({ ...prev, [cid]: [...(prev[cid] || []), optimistic] }));
    socket.emit('message:send', {
      ...payload, tempId,
      receiver: activeChat.chatType === 'user' ? cid : undefined,
      group: activeChat.chatType === 'group' ? cid : undefined,
    });
  }, [socket, activeChat, user]);

  const reactToMessage = useCallback((messageId, emoji) => {
    socket?.emit('message:react', { messageId, emoji });
    setMessages(prev => {
      const updated = {};
      Object.keys(prev).forEach(cid => {
        updated[cid] = prev[cid].map(m => {
          if (m._id !== messageId) return m;
          const reactions = [...(m.reactions || [])];
          const ex = reactions.find(r => (r.user?._id || r.user) === user._id);
          if (ex) { if (ex.emoji === emoji) return { ...m, reactions: reactions.filter(r => (r.user?._id || r.user) !== user._id) }; ex.emoji = emoji; return { ...m, reactions }; }
          return { ...m, reactions: [...reactions, { user: { _id: user._id }, emoji }] };
        });
      });
      return updated;
    });
  }, [socket, user]);

  const starMessage = useCallback(async (messageId) => {
    try {
      const res = await axios.post(`${API}/messages/${messageId}/star`);
      setMessages(prev => {
        const updated = {};
        Object.keys(prev).forEach(cid => { updated[cid] = prev[cid].map(m => m._id === messageId ? { ...m, isStarred: res.data.starred } : m); });
        return updated;
      });
    } catch(e) {}
  }, []);

  const deleteMessage = useCallback((messageId, deleteType) => {
    socket?.emit('message:delete', { messageId, deleteType });
    setMessages(prev => {
      const updated = {};
      Object.keys(prev).forEach(cid => {
        updated[cid] = prev[cid].map(m => {
          if (m._id !== messageId) return m;
          if (deleteType === 'everyone') return { ...m, deletedForEveryone: true, content: 'This message was deleted', mediaUrl: '' };
          return { ...m, deletedForMe: true };
        }).filter(m => !m.deletedForMe);
      });
      return updated;
    });
  }, [socket]);

  const editMessage = useCallback((messageId, content) => {
    socket?.emit('message:edit', { messageId, content });
    setMessages(prev => {
      const updated = {};
      Object.keys(prev).forEach(cid => { updated[cid] = prev[cid].map(m => m._id === messageId ? { ...m, content, isEdited: true } : m); });
      return updated;
    });
  }, [socket]);

  const votePoll = useCallback((messageId, optionIndex) => {
    socket?.emit('poll:vote', { messageId, optionIndex });
  }, [socket]);

  const loadStarred = useCallback(async () => {
    try { const res = await axios.get(`${API}/messages/starred`); setStarredMsgs(res.data); }
    catch(e) {}
  }, []);

  const loadScheduled = useCallback(async () => {
    try { const res = await axios.get(`${API}/messages/scheduled`); setScheduledMsgs(res.data); }
    catch(e) {}
  }, []);

  const archiveChat = (id) => setArchivedIds(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]);
  const pinChat = (id) => setPinnedIds(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]);
  const muteChat = (id) => setMutedIds(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]);

  return (
    <ChatContext.Provider value={{
      contacts, setContacts, groups, setGroups,
      activeChat, openChat, setActiveChat,
      messages, setMessages, sendMessage,
      reactToMessage, starMessage, deleteMessage, editMessage, votePoll,
      archivedIds, pinnedIds, mutedIds,
      archiveChat, pinChat, muteChat,
      unreadCounts, typingUsers,
      starredMsgs, loadStarred,
      scheduledMsgs, loadScheduled, setScheduledMsgs,
      loadContacts, loadMessages,
    }}>
      {children}
    </ChatContext.Provider>
  );
};
