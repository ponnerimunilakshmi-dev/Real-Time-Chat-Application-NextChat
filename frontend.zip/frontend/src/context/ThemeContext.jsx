import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

const ThemeContext = createContext();
export const useTheme = () => useContext(ThemeContext);

const PRESETS = {
  dark: { bg: '#0a0f1e', sidebar: '#111827', chat: '#0d1117', bubble: '#00b4d8', bubbleText: '#fff', text: '#e2e8f0', accent: '#00b4d8' },
  light: { bg: '#f0f2f5', sidebar: '#fff', chat: '#e5ddd5', bubble: '#25d366', bubbleText: '#fff', text: '#111827', accent: '#128c7e' },
  ocean: { bg: '#0a1628', sidebar: '#0d2040', chat: '#0a1628', bubble: '#0077b6', bubbleText: '#fff', text: '#caf0f8', accent: '#00b4d8' },
  forest: { bg: '#0d1f0d', sidebar: '#122912', chat: '#0d1f0d', bubble: '#2d6a4f', bubbleText: '#fff', text: '#d8f3dc', accent: '#40916c' },
  sunset: { bg: '#1a0a0a', sidebar: '#2d1515', chat: '#1a0a0a', bubble: '#e63946', bubbleText: '#fff', text: '#ffc8c8', accent: '#e63946' },
  purple: { bg: '#0d0720', sidebar: '#130d2e', chat: '#0d0720', bubble: '#7b2d8b', bubbleText: '#fff', text: '#e8c9f5', accent: '#9b59b6' },
};

export const ThemeProvider = ({ children }) => {
  const { user } = useAuth();
  const [currentTheme, setCurrentTheme] = useState('dark');
  const [customBg, setCustomBg] = useState(null);
  const [colors, setColors] = useState(PRESETS.dark);

  useEffect(() => {
    if (user?.theme) {
      if (user.theme.type === 'custom') {
        setCustomBg(user.theme.value);
        setCurrentTheme('custom');
      } else {
        const preset = user.theme.value || 'dark';
        setCurrentTheme(preset);
        setColors(PRESETS[preset] || PRESETS.dark);
      }
    }
  }, [user]);

  useEffect(() => {
    if (currentTheme !== 'custom') {
      setColors(PRESETS[currentTheme] || PRESETS.dark);
    }
    // Apply CSS vars
    const theme = PRESETS[currentTheme] || PRESETS.dark;
    Object.entries(theme).forEach(([key, val]) => {
      document.documentElement.style.setProperty(`--${key}`, val);
    });
  }, [currentTheme]);

  const applyPreset = (name) => {
    setCurrentTheme(name);
    setCustomBg(null);
  };

  const applyCustomBg = (url) => {
    setCustomBg(url);
    setCurrentTheme('custom');
  };

  return (
    <ThemeContext.Provider value={{ currentTheme, colors, customBg, applyPreset, applyCustomBg, PRESETS }}>
      {children}
    </ThemeContext.Provider>
  );
};
