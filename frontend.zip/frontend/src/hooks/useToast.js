import { useState, useCallback } from 'react';
let toastFn = null;
export const showToast = (msg, type = 'info') => toastFn?.(msg, type);
export const useToastProvider = () => {
  const [toasts, setToasts] = useState([]);
  toastFn = useCallback((msg, type = 'info') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, msg, type }]);
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 3000);
  }, []);
  return toasts;
};
