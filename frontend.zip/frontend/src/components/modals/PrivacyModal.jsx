import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAuth } from '../../context/AuthContext';
import { showToast } from '../../hooks/useToast';
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
export default function PrivacyModal({ onClose }) {
  const { user, updateUser } = useAuth();
  const [privacy, setPrivacy] = useState({ lastSeen: 'everyone', onlineStatus: 'everyone', profilePhoto: 'everyone', readReceipts: true, ...user?.privacy });
  const [disappear, setDisappear] = useState(user?.disappearingMessages || 0);
  const [username, setUsername] = useState(user?.username || '');
  const [twoFAEnabled, setTwoFAEnabled] = useState(user?.twoFA?.enabled || false);
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinAction, setPinAction] = useState(null);
  const [pin, setPin] = useState(['','','','','','']);

  const savePrivacy = async () => {
    try { const res = await axios.put(`${API}/users/privacy`, privacy); updateUser?.(res.data); showToast('✅ Privacy saved'); } catch { showToast('❌ Failed', 'error'); }
  };
  const saveDisappear = async (v) => {
    setDisappear(v);
    try { await axios.put(`${API}/users/disappearing`, { seconds: v }); showToast(v ? `⏱ Disappearing: ${v === 86400 ? '24h' : v === 604800 ? '7 days' : '30 days'}` : '⏱ Off'); } catch {}
  };
  const saveUsername = async () => {
    const u = username.replace(/^@/, '');
    try { const res = await axios.put(`${API}/users/profile`, { username: u }); updateUser?.(res.data); showToast('✅ Username @' + u + ' saved!'); } catch (e) { showToast('❌ ' + e.response?.data?.message, 'error'); }
  };
  const handleToggle2FA = () => {
    setPinAction(twoFAEnabled ? 'disable' : 'enable');
    setPin(['','','','','','']);
    setShowPinModal(true);
  };
  const confirm2FA = async () => {
    const code = pin.join('');
    if (code.length < 6) return;
    try {
      if (pinAction === 'enable') { await axios.post(`${API}/users/2fa/enable`, { pin: code }); setTwoFAEnabled(true); showToast('🔐 2FA enabled'); }
      else { await axios.post(`${API}/users/2fa/disable`, { pin: code }); setTwoFAEnabled(false); showToast('🔓 2FA disabled'); }
      setShowPinModal(false);
    } catch (e) { showToast('❌ Wrong PIN', 'error'); setPin(['','','','','','']); }
  };
  const P = ({ label, sub, name }) => (
    <div className="priv-row">
      <div><div style={{ fontSize: 14 }}>{label}</div>{sub && <div style={{ fontSize: 12, opacity: 0.4 }}>{sub}</div>}</div>
      <select className="priv-select" value={privacy[name] || 'everyone'} onChange={e => { const n = { ...privacy, [name]: e.target.value }; setPrivacy(n); }}>
        <option value="everyone">Everyone</option><option value="contacts">Contacts</option><option value="nobody">Nobody</option>
      </select>
    </div>
  );
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: 460 }} onClick={e => e.stopPropagation()}>
        <div className="modal-title">🔒 Privacy & Security <button className="modal-close" onClick={onClose}>✕</button></div>
        <div className="settings-section">PRIVACY</div>
        <P label="Last Seen" sub="Who can see your last seen" name="lastSeen" />
        <P label="Online Status" sub="Who can see when you're online" name="onlineStatus" />
        <P label="Profile Photo" name="profilePhoto" />
        <div className="priv-row">
          <div><div style={{ fontSize: 14 }}>Read Receipts</div><div style={{ fontSize: 12, opacity: 0.4 }}>Show blue ticks</div></div>
          <div className={`toggle ${privacy.readReceipts ? 'on' : ''}`} onClick={() => setPrivacy(p => ({ ...p, readReceipts: !p.readReceipts }))} />
        </div>
        <button className="btn-secondary" style={{ marginTop: 10 }} onClick={savePrivacy}>Save Privacy</button>

        <div className="settings-section" style={{ marginTop: 20 }}>SECURITY</div>
        <div className="priv-row">
          <div><div style={{ fontSize: 14 }}>Two-Factor Auth</div><div style={{ fontSize: 12, opacity: 0.4 }}>{twoFAEnabled ? '2FA active — PIN required at login' : 'Set 6-digit PIN'}</div></div>
          <div className={`toggle ${twoFAEnabled ? 'on' : ''}`} onClick={handleToggle2FA} />
        </div>
        <div className="priv-row" style={{ alignItems: 'flex-start', flexDirection: 'column', gap: 8 }}>
          <div style={{ fontSize: 14 }}>@Username</div>
          <div style={{ display: 'flex', gap: 8, width: '100%' }}>
            <input className="form-input" style={{ margin: 0, flex: 1 }} placeholder="@username" value={username} onChange={e => setUsername(e.target.value)} />
            <button className="btn-primary" style={{ width: 'auto', padding: '10px 14px' }} onClick={saveUsername}>Save</button>
          </div>
        </div>

        <div className="settings-section" style={{ marginTop: 20 }}>DISAPPEARING MESSAGES</div>
        <div className="priv-row">
          <div style={{ fontSize: 14 }}>Auto-delete new messages</div>
          <select className="priv-select" value={disappear} onChange={e => saveDisappear(Number(e.target.value))}>
            <option value={0}>Off</option><option value={86400}>24 hours</option><option value={604800}>7 days</option><option value={2592000}>30 days</option>
          </select>
        </div>
      </div>
      {showPinModal && (
        <div className="modal-overlay" style={{ zIndex: 1001 }} onClick={() => setShowPinModal(false)}>
          <div className="modal-box" style={{ maxWidth: 340 }} onClick={e => e.stopPropagation()}>
            <div className="modal-title">{pinAction === 'enable' ? 'Set 2FA PIN' : 'Enter Current PIN'}</div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center', margin: '20px 0' }}>
              {pin.map((d, i) => <input key={i} type="password" maxLength={1} value={d} className="otp-box" onChange={e => { const n = [...pin]; n[i] = e.target.value.replace(/\D/, ''); setPin(n); if (e.target.value && i < 5) document.getElementById(`pin${i+1}`)?.focus(); }} id={`pin${i}`} onKeyDown={e => { if (e.key === 'Backspace' && !pin[i] && i > 0) { const n=[...pin]; n[i-1]=''; setPin(n); document.getElementById(`pin${i-1}`)?.focus(); } }} />)}
            </div>
            <button className="btn-primary" onClick={confirm2FA}>Confirm</button>
          </div>
        </div>
      )}
    </div>
  );
}
