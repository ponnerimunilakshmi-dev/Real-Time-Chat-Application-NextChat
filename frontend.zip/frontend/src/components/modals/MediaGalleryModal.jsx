import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useChat } from '../../context/ChatContext';
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const fmt = d => new Date(d).toLocaleDateString();
export default function MediaGalleryModal({ onClose }) {
  const { activeChat } = useChat();
  const [tab, setTab] = useState('media');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { load(); }, [tab]);
  const load = async () => {
    setLoading(true);
    try {
      const ct = activeChat?.chatType === 'group' ? 'group' : 'user';
      const res = await axios.get(`${API}/messages/media/${activeChat._id}?chatType=${ct}`);
      setItems(res.data);
    } catch { setItems([]); }
    setLoading(false);
  };
  const filtered = items.filter(m => tab === 'media' ? ['image','video','gif'].includes(m.type) : tab === 'docs' ? m.type === 'document' : m.type === 'link');
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: 500 }} onClick={e => e.stopPropagation()}>
        <div className="modal-title">📁 Media, Links & Docs <button className="modal-close" onClick={onClose}>✕</button></div>
        <div className="tab-row" style={{ marginBottom: 14 }}>
          {['media','docs','links'].map(t => <button key={t} className={`tab-btn ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>{t === 'media' ? '📷 Media' : t === 'docs' ? '📄 Docs' : '🔗 Links'}</button>)}
        </div>
        {loading ? <div className="loading-state">Loading...</div> : filtered.length === 0 ? <div className="empty-state">Nothing here yet</div> : (
          <div style={{ maxHeight: 360, overflowY: 'auto' }}>
            {tab === 'media' ? (
              <div className="media-grid">
                {filtered.map(m => m.type === 'image' ? (
                  <img key={m._id} src={m.mediaUrl} alt="" className="media-thumb" onClick={() => window.open(m.mediaUrl, '_blank')} />
                ) : (
                  <div key={m._id} className="media-thumb video-thumb" onClick={() => window.open(m.mediaUrl, '_blank')}>🎬</div>
                ))}
              </div>
            ) : (
              filtered.map(m => (
                <a key={m._id} className="doc-row" href={m.mediaUrl || m.linkPreview?.url} target="_blank" rel="noopener noreferrer">
                  <span style={{ fontSize: 22 }}>{m.type === 'document' ? '📄' : '🔗'}</span>
                  <div><div style={{ fontWeight: 600, fontSize: 13 }}>{m.mediaName || m.linkPreview?.title || m.content}</div><div style={{ fontSize: 11, opacity: 0.5 }}>{fmt(m.createdAt)}</div></div>
                </a>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
