import React, { useState } from 'react';
import axios from 'axios';
import { useChat } from '../../context/ChatContext';
import { showToast } from '../../hooks/useToast';
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
export default function InviteLinkModal({ group, onClose }) {
  const { setGroups } = useChat();
  const [link, setLink] = useState(`${window.location.origin}?join=${group.inviteLink}`);
  const copy = () => { navigator.clipboard?.writeText(link); showToast('📋 Copied!'); };
  const regen = async () => {
    try {
      const res = await axios.post(`${API}/groups/${group._id}/regenerate-invite`);
      const newLink = `${window.location.origin}?join=${res.data.inviteLink}`;
      setLink(newLink);
      setGroups(prev => prev.map(g => g._id === group._id ? { ...g, inviteLink: res.data.inviteLink } : g));
      showToast('🔄 New link generated');
    } catch { showToast('❌ Failed', 'error'); }
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: 420 }} onClick={e => e.stopPropagation()}>
        <div className="modal-title">🔗 Invite Link <button className="modal-close" onClick={onClose}>✕</button></div>
        <div className="invite-link-box" onClick={copy}>{link}</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button className="btn-primary" style={{ flex: 1 }} onClick={copy}>📋 Copy</button>
          <button className="btn-secondary" style={{ flex: 1 }} onClick={regen}>🔄 New Link</button>
        </div>
      </div>
    </div>
  );
}
