import React, { useState, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import { showToast } from '../../hooks/useToast';
export default function GifModal({ onClose }) {
  const { sendMessage } = useChat();
  const [q, setQ] = useState('');
  const [gifs, setGifs] = useState([]);
  const [loading, setLoading] = useState(false);
  useEffect(() => { search('trending'); }, []);
  let debounce;
  const search = async (query) => {
    setLoading(true);
    try {
      const res = await fetch(`https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(query || 'trending')}&key=AIzaSyAyimkuYQYF_FXVALexPzfiber46B0pbrBo&limit=12&media_filter=gif`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      setGifs(data.results || []);
    } catch { showToast('GIF service unavailable'); setGifs([]); }
    setLoading(false);
  };
  const handleQ = (v) => { setQ(v); clearTimeout(debounce); debounce = setTimeout(() => search(v || 'trending'), 500); };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-title">🎞️ Send GIF <button className="modal-close" onClick={onClose}>✕</button></div>
        <input className="form-input" placeholder="Search GIFs..." value={q} onChange={e => handleQ(e.target.value)} style={{ marginBottom: 12 }} />
        {loading ? <div className="loading-state">Loading...</div> : (
          <div className="gif-grid">
            {gifs.map(g => {
              const src = g.media_formats?.gif?.url || g.media_formats?.tinygif?.url;
              return src ? (
                <div key={g.id} className="gif-item" onClick={() => { sendMessage({ type: 'gif', gifUrl: src, content: 'GIF' }); onClose(); }}>
                  <img src={src} alt="gif" loading="lazy" />
                </div>
              ) : null;
            })}
          </div>
        )}
      </div>
    </div>
  );
}
