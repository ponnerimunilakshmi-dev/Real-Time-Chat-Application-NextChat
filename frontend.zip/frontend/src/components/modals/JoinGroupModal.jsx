import React, { useState } from 'react';
import axios from 'axios';
import { useChat } from '../../context/ChatContext';
import { useSocket } from '../../context/SocketContext';
import { showToast } from '../../hooks/useToast';
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
export default function JoinGroupModal({ onClose }) {
  const { setGroups } = useChat();
  const { socket } = useSocket();
  const [val, setVal] = useState('');
  const join = async () => {
    const code = val.split('?join=').pop().split('/').pop().trim();
    if (!code) return showToast('⚠️ Enter a link or code');
    try {
      const res = await axios.post(`${API}/groups/join/${code}`);
      setGroups(prev => prev.find(g => g._id === res.data._id) ? prev : [...prev, res.data]);
      socket?.emit('group:join', { groupId: res.data._id });
      showToast('👥 Joined ' + res.data.name + '!');
      onClose();
    } catch (e) { showToast('❌ ' + (e.response?.data?.message || 'Invalid link'), 'error'); }
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-title">🔗 Join Group <button className="modal-close" onClick={onClose}>✕</button></div>
        <label className="form-label">Invite Link or Code</label>
        <input className="form-input" placeholder="Paste invite link..." value={val} onChange={e => setVal(e.target.value)} />
        <button className="btn-primary" onClick={join}>Join Group</button>
      </div>
    </div>
  );
}
