import React, { useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
import { useAuth } from '../../context/AuthContext';
const fmt = d => new Date(d).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
export default function StarredModal({ onClose }) {
  const { user } = useAuth();
  const { starredMsgs, loadStarred, starMessage, contacts } = useChat();
  useEffect(() => { loadStarred(); }, []);
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: 480 }} onClick={e => e.stopPropagation()}>
        <div className="modal-title">⭐ Starred Messages <button className="modal-close" onClick={onClose}>✕</button></div>
        {starredMsgs.length === 0 ? (
          <div className="empty-state">⭐<br/>No starred messages yet</div>
        ) : (
          <div style={{ maxHeight: 380, overflowY: 'auto' }}>
            {starredMsgs.map(msg => {
              const sid = msg.sender?._id || msg.sender;
              const isMine = sid === user._id;
              const peer = contacts.find(c => c._id === (isMine ? msg.receiver : sid)) || msg.sender;
              return (
                <div key={msg._id} className="starred-row">
                  <div className="conv-avatar placeholder" style={{ width: 38, height: 38 }}>{(peer?.name || '?')[0].toUpperCase()}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.35)', marginBottom: 2 }}>{peer?.name} · {fmt(msg.createdAt)}</div>
                    <div style={{ fontSize: 14 }}>{msg.content || '📎 Media'}</div>
                  </div>
                  <button className="icon-btn" style={{ color: '#fbbf24' }} onClick={() => starMessage(msg._id)}>⭐</button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
