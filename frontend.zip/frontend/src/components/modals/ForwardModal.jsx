import React, { useState } from 'react';
import { useChat } from '../../context/ChatContext';
import { useSocket } from '../../context/SocketContext';
import { showToast } from '../../hooks/useToast';
export default function ForwardModal({ msg, onClose }) {
  const { contacts, groups } = useChat();
  const { socket } = useSocket();
  const [selected, setSelected] = useState(new Set());
  const [q, setQ] = useState('');
  const all = [...contacts, ...groups];
  const filtered = all.filter(i => i.name?.toLowerCase().includes(q.toLowerCase()));
  const toggle = (id) => setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const send = () => {
    if (!selected.size) { showToast('⚠️ Select at least one'); return; }
    selected.forEach(id => {
      const isGrp = groups.some(g => g._id === id);
      socket?.emit('message:send', {
        receiver: isGrp ? undefined : id,
        group: isGrp ? id : undefined,
        type: msg.type || 'text', content: msg.content || '',
        gifUrl: msg.gifUrl, mediaUrl: msg.mediaUrl, sticker: msg.sticker,
        isForwarded: true, forwardedFrom: msg._id,
        tempId: 'fwd_' + Date.now() + '_' + id
      });
    });
    showToast(`↪️ Forwarded to ${selected.size} chat(s)`);
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-title">↪️ Forward Message <button className="modal-close" onClick={onClose}>✕</button></div>
        <input className="form-input" placeholder="Search..." value={q} onChange={e => setQ(e.target.value)} style={{ marginBottom: 12 }} />
        <div style={{ maxHeight: 280, overflowY: 'auto' }}>
          {filtered.map(item => (
            <div key={item._id} className={`fwd-item ${selected.has(item._id) ? 'selected' : ''}`} onClick={() => toggle(item._id)}>
              <div className={`fwd-check ${selected.has(item._id) ? 'on' : ''}`}>{selected.has(item._id) ? '✓' : ''}</div>
              <div className="conv-avatar placeholder" style={{ width: 36, height: 36, fontSize: 14 }}>{item.name?.[0]?.toUpperCase()}</div>
              <span style={{ fontWeight: 500 }}>{item.name}</span>
            </div>
          ))}
        </div>
        <button className="btn-primary" style={{ marginTop: 12 }} onClick={send} disabled={!selected.size}>↪️ Forward to {selected.size} chat{selected.size !== 1 ? 's' : ''}</button>
      </div>
    </div>
  );
}
