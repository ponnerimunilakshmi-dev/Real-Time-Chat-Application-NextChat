import React, { useState } from 'react';
import { useChat } from '../../context/ChatContext';
export default function PollModal({ onClose }) {
  const { sendMessage } = useChat();
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);
  const [multi, setMulti] = useState(false);
  const submit = () => {
    if (!question.trim()) return;
    const opts = options.filter(o => o.trim());
    if (opts.length < 2) return;
    sendMessage({ type: 'poll', content: question, poll: { question, options: opts, multipleChoice: multi } });
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-title">📊 Create Poll <button className="modal-close" onClick={onClose}>✕</button></div>
        <label className="form-label">Question</label>
        <input className="form-input" placeholder="Ask a question..." value={question} onChange={e => setQuestion(e.target.value)} />
        <label className="form-label" style={{ marginTop: 14 }}>Options</label>
        {options.map((o, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
            <input className="form-input" placeholder={`Option ${i + 1}`} value={o} onChange={e => { const n = [...options]; n[i] = e.target.value; setOptions(n); }} style={{ margin: 0 }} />
            {options.length > 2 && <button className="icon-btn" onClick={() => setOptions(options.filter((_, j) => j !== i))}>✕</button>}
          </div>
        ))}
        {options.length < 4 && <button className="btn-secondary" onClick={() => setOptions([...options, ''])} style={{ marginBottom: 14 }}>+ Add Option</button>}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
          <div className={`toggle ${multi ? 'on' : ''}`} onClick={() => setMulti(v => !v)} />
          <span style={{ fontSize: 13 }}>Multiple choice</span>
        </div>
        <button className="btn-primary" onClick={submit}>📊 Send Poll</button>
      </div>
    </div>
  );
}
