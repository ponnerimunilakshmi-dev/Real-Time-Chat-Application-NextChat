import React, { useState, useRef, useEffect } from 'react';

const PRESET_THEMES = {
  default:  { label: 'Default',  colors: ['#0a0f1e', '#00b4d8'], bubble: '#00b4d8', chat: '#0d1117' },
  rose:     { label: 'Rose',     colors: ['#1a0a0f', '#e11d48'], bubble: '#e11d48', chat: '#1a0a0f' },
  violet:   { label: 'Violet',   colors: ['#0d0720', '#7c3aed'], bubble: '#7c3aed', chat: '#0d0720' },
  emerald:  { label: 'Emerald',  colors: ['#021a0a', '#059669'], bubble: '#059669', chat: '#021a0a' },
  amber:    { label: 'Amber',    colors: ['#1a1000', '#d97706'], bubble: '#d97706', chat: '#1a1000' },
  sky:      { label: 'Sky',      colors: ['#020e1a', '#0891b2'], bubble: '#0891b2', chat: '#020e1a' },
  pink:     { label: 'Pink',     colors: ['#1a0012', '#db2777'], bubble: '#db2777', chat: '#1a0012' },
  teal:     { label: 'Teal',     colors: ['#001a18', '#0d9488'], bubble: '#0d9488', chat: '#001a18' },
};

const NOTIFICATION_SOUNDS = [
  { id: 'default', label: '🔔 Default',    freq: 880, type: 'sine'     },
  { id: 'soft',    label: '🎵 Soft Chime', freq: 660, type: 'sine'     },
  { id: 'ping',    label: '🏓 Ping',       freq: 1200, type: 'triangle' },
  { id: 'pop',     label: '💬 Pop',        freq: 400, type: 'sine'     },
  { id: 'bell',    label: '🔕 Silent',     freq: 0,   type: 'sine'     },
];

function playPreviewSound(soundId) {
  const sound = NOTIFICATION_SOUNDS.find(s => s.id === soundId);
  if (!sound || sound.freq === 0) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = sound.type;
    osc.frequency.setValueAtTime(sound.freq, ctx.currentTime);
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.4);
  } catch {}
}

const STORAGE_KEY = 'nc_contact_settings';

export function getContactSettings(contactId) {
  try {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return all[contactId] || { theme: 'default', sound: 'default', notifEnabled: true, notifPreview: true };
  } catch { return { theme: 'default', sound: 'default', notifEnabled: true, notifPreview: true }; }
}

export function saveContactSettings(contactId, settings) {
  try {
    const all = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    all[contactId] = { ...all[contactId], ...settings };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
  } catch {}
}

export { PRESET_THEMES, NOTIFICATION_SOUNDS, playPreviewSound };

export default function ContactSettingsModal({ contact, onClose }) {
  const current = getContactSettings(contact._id);
  const [theme, setTheme]           = useState(current.theme || 'default');
  const [sound, setSound]           = useState(current.sound || 'default');
  const [notifEnabled, setNotifEnabled] = useState(current.notifEnabled !== false);
  const [notifPreview, setNotifPreview] = useState(current.notifPreview !== false);
  const [customBg, setCustomBg]     = useState(current.customBg || null);
  const [saved, setSaved]           = useState(false);
  const fileRef = useRef();

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);

  const handleSave = () => {
    saveContactSettings(contact._id, { theme, sound, notifEnabled, notifPreview, customBg });
    setSaved(true);
    setTimeout(() => { setSaved(false); onClose(); }, 800);
  };

  const handleCustomBg = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      setCustomBg(ev.target.result);
      setTheme('custom');
    };
    reader.readAsDataURL(file);
  };

  const previewTheme = theme === 'custom' ? null : PRESET_THEMES[theme] || PRESET_THEMES.default;

  return (
    <div className={`modal-overlay ${isMobile ? 'cs-modal-overlay-mobile' : ''}`} onClick={onClose}>
      <div
        className="modal-box contact-settings-modal"
        onClick={e => e.stopPropagation()}
        style={{ maxWidth: 440, width: '95%', maxHeight: '90vh', overflowY: 'auto' }}
      >
        {/* Header */}
        <div className="modal-title" style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1 }}>
            {contact.avatar
              ? <img src={contact.avatar} alt="" style={{ width: 36, height: 36, borderRadius: '50%', objectFit: 'cover' }} />
              : <div style={{ width: 36, height: 36, borderRadius: '50%', background: '#00b4d8', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 16 }}>{contact.name?.[0]?.toUpperCase()}</div>
            }
            <span style={{ fontSize: 15 }}>Chat Settings — {contact.name}</span>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {/* ── THEME SECTION ── */}
        <div className="cs-section">
          <div className="cs-section-title">🎨 Chat Theme</div>
          <div className="cs-section-sub">Applied only for this conversation</div>

          {/* Live preview bubble */}
          <div className="cs-preview" style={{
            background: theme === 'custom' && customBg
              ? `url(${customBg}) center/cover`
              : (previewTheme?.chat || '#0d1117'),
            transition: 'background 0.3s ease'
          }}>
            <div className="cs-preview-bubble received" style={{ background: 'rgba(255,255,255,0.12)' }}>
              Hey! How are you? 👋
            </div>
            <div className="cs-preview-bubble sent" style={{ background: previewTheme?.bubble || '#00b4d8' }}>
              Doing great, thanks! 😊
            </div>
          </div>

          {/* Theme grid */}
          <div className="cs-theme-grid">
            {Object.entries(PRESET_THEMES).map(([key, t]) => (
              <div
                key={key}
                className={`cs-theme-swatch ${theme === key ? 'active' : ''}`}
                style={{ background: `linear-gradient(135deg, ${t.colors[0]}, ${t.colors[1]})` }}
                onClick={() => { setTheme(key); setCustomBg(null); }}
                title={t.label}
              >
                <span>{t.label}</span>
                {theme === key && <div className="cs-swatch-check">✓</div>}
              </div>
            ))}
          </div>

          {/* Custom background */}
          <button className="btn-secondary cs-upload-btn" onClick={() => fileRef.current?.click()}>
            📷 Upload Custom Background
          </button>
          <input ref={fileRef} type="file" hidden accept="image/*" onChange={handleCustomBg} />
          {theme === 'custom' && customBg && (
            <div style={{ fontSize: 12, color: '#22c55e', marginTop: 6 }}>✓ Custom background applied</div>
          )}
        </div>

        {/* ── NOTIFICATION SECTION ── */}
        <div className="cs-section">
          <div className="cs-section-title">🔔 Notifications</div>

          <div className="cs-toggle-row">
            <div>
              <div className="cs-toggle-label">Enable Notifications</div>
              <div className="cs-toggle-sub">Show alerts for new messages</div>
            </div>
            <div
              className={`toggle ${notifEnabled ? 'on' : ''}`}
              onClick={() => setNotifEnabled(v => !v)}
            />
          </div>

          {notifEnabled && (
            <div className="cs-toggle-row">
              <div>
                <div className="cs-toggle-label">Message Preview</div>
                <div className="cs-toggle-sub">Show message text in notification</div>
              </div>
              <div
                className={`toggle ${notifPreview ? 'on' : ''}`}
                onClick={() => setNotifPreview(v => !v)}
              />
            </div>
          )}
        </div>

        {/* ── SOUND SECTION ── */}
        <div className="cs-section">
          <div className="cs-section-title">🎵 Message Sound</div>
          <div className="cs-section-sub">Tap any sound to preview it</div>

          <div className="cs-sound-list">
            {NOTIFICATION_SOUNDS.map(s => (
              <div
                key={s.id}
                className={`cs-sound-item ${sound === s.id ? 'active' : ''}`}
                onClick={() => { setSound(s.id); playPreviewSound(s.id); }}
              >
                <span>{s.label}</span>
                {sound === s.id && <span className="cs-sound-check">✓</span>}
              </div>
            ))}
          </div>
        </div>

        {/* Save */}
        <button className="btn-primary" style={{ width: '100%', marginTop: 8 }} onClick={handleSave}>
          {saved ? '✓ Saved!' : '💾 Save Settings'}
        </button>
      </div>
    </div>
  );
}
