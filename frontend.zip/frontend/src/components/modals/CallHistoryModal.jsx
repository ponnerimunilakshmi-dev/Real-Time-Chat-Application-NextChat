import React, { useEffect, useState } from 'react';
import axios from 'axios';
const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const fmt = d => new Date(d).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
export default function CallHistoryModal({ onClose, onCall }) {
  const [calls, setCalls] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => { axios.get(`${API}/users/calls`).then(r => setCalls(r.data)).catch(() => {}).finally(() => setLoading(false)); }, []);
  const icons = { outgoing: '📲', incoming: '📞', missed: '❌' };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" style={{ maxWidth: 420 }} onClick={e => e.stopPropagation()}>
        <div className="modal-title">📞 Call History <button className="modal-close" onClick={onClose}>✕</button></div>
        {loading ? <div className="loading-state">Loading...</div> : calls.length === 0 ? <div className="empty-state">No call history</div> : (
          <div style={{ maxHeight: 380, overflowY: 'auto' }}>
            {calls.map((c, i) => (
              <div key={i} className="call-row">
                <div className="conv-avatar placeholder" style={{ width: 42, height: 42 }}>{(c.peer?.name || '?')[0]?.toUpperCase()}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{c.peer?.name || 'Unknown'}</div>
                  <div style={{ fontSize: 12, opacity: 0.5 }}>{icons[c.direction]} {c.direction} {c.callType === 'video' ? '📹' : ''} · {fmt(c.startedAt)} {c.duration ? `· ${Math.floor(c.duration/60)}m ${c.duration%60}s` : ''}</div>
                </div>
                {c.peer && <button className="icon-btn" onClick={() => { onCall(c.peer, c.callType); onClose(); }}>{c.callType === 'video' ? '📹' : '📞'}</button>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
