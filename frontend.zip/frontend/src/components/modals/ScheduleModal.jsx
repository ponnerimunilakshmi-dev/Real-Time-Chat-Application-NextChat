import React, { useState } from 'react';
import { useChat } from '../../context/ChatContext';
import { useSocket } from '../../context/SocketContext';
import { showToast } from '../../hooks/useToast';
export default function ScheduleModal({ onClose, draft }) {
  const { activeChat } = useChat();
  const { socket } = useSocket();
  const [msg, setMsg] = useState(draft || '');
  const [time, setTime] = useState('');
  const submit = () => {
    if (!msg.trim()) { showToast('⚠️ Enter a message'); return; }
    if (!time || new Date(time) <= new Date()) { showToast('⚠️ Pick a future time'); return; }
    socket?.emit('message:send', {
      receiver: activeChat?.chatType === 'user' ? activeChat._id : undefined,
      group: activeChat?.chatType === 'group' ? activeChat._id : undefined,
      type: 'text', content: msg, scheduledAt: new Date(time).toISOString(), tempId: 'sched_' + Date.now()
    });
    showToast('⏰ Message scheduled!');
    onClose();
  };
  const min = new Date(); min.setMinutes(min.getMinutes() + 1);
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-title">⏰ Schedule Message <button className="modal-close" onClick={onClose}>✕</button></div>
        <div className="info-banner">⚠️ Server must be running at scheduled time</div>
        <label className="form-label">Message</label>
        <textarea className="form-input" rows={3} placeholder="Your message..." value={msg} onChange={e => setMsg(e.target.value)} style={{ resize: 'none' }} />
        <label className="form-label" style={{ marginTop: 14 }}>Date & Time</label>
        <input className="form-input" type="datetime-local" value={time} min={min.toISOString().slice(0, 16)} onChange={e => setTime(e.target.value)} />
        <button className="btn-primary" style={{ marginTop: 14 }} onClick={submit}>⏰ Schedule</button>
      </div>
    </div>
  );
}
