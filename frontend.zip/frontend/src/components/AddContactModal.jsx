import React, { useState } from 'react';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function AddContactModal({ onClose, onAdded }) {
  const [phone, setPhone] = useState('');
  const [name, setName]   = useState('');
  const [found, setFound] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState('input'); // 'input' | 'confirm'

  const handleSearch = async () => {
    if (!phone || phone.length < 6) return setError('Enter a valid phone number');
    if (!name.trim()) return setError('Enter a name for this contact');
    setError(''); setFound(null); setLoading(true);
    try {
      const res = await axios.get(`${API}/users/search?phone=${encodeURIComponent(phone)}`);
      setFound({ ...res.data, displayName: name.trim() });
      setStep('confirm');
    } catch (e) {
      setError(e.response?.data?.message || 'This number is not registered on NexChat');
    }
    setLoading(false);
  };

  const handleAdd = async () => {
    try {
      setLoading(true);
      const res = await axios.post(`${API}/users/contacts`, { phone });
      // Use user-provided name instead of registered name
      onAdded({ ...res.data.contact, name: name.trim() || res.data.contact.name });
      onClose();
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to add contact');
    }
    setLoading(false);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title">
          ➕ Add Contact
          <button onClick={onClose} style={{ background:'none',border:'none',color:'rgba(255,255,255,0.5)',cursor:'pointer',fontSize:20 }}>✕</button>
        </div>

        {error && <div className="error-msg">⚠️ {error}</div>}

        {step === 'input' && (
          <>
            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input
                className="form-input"
                placeholder="Enter phone number"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && document.getElementById('nameInput')?.focus()}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Name</label>
              <input
                id="nameInput"
                className="form-input"
                placeholder="Enter contact name"
                value={name}
                onChange={e => setName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <button className="btn-primary" onClick={handleSearch} disabled={loading}>
              {loading ? 'Searching...' : '🔍 Find & Add'}
            </button>
          </>
        )}

        {step === 'confirm' && found && (
          <>
            <div style={{ background:'rgba(0,180,216,0.08)',border:'1px solid rgba(0,180,216,0.2)',borderRadius:14,padding:16,display:'flex',alignItems:'center',gap:14,marginBottom:16 }}>
              {found.avatar
                ? <img src={found.avatar} alt="" style={{ width:48,height:48,borderRadius:'50%',objectFit:'cover' }} />
                : <div className="avatar-placeholder">{(found.displayName||found.name)?.[0]?.toUpperCase()}</div>
              }
              <div>
                <div style={{ fontWeight:700 }}>{found.displayName}</div>
                <div style={{ fontSize:13,color:'rgba(255,255,255,0.4)' }}>{found.phone}</div>
                <div style={{ fontSize:12,color:'rgba(255,255,255,0.3)' }}>Registered on NexChat ✓</div>
              </div>
            </div>
            <button className="btn-primary" onClick={handleAdd} disabled={loading}>
              {loading ? 'Adding...' : `➕ Add ${found.displayName}`}
            </button>
            <button className="btn-secondary" onClick={() => setStep('input')} style={{ marginTop:8 }}>
              ← Back
            </button>
          </>
        )}
      </div>
    </div>
  );
}
