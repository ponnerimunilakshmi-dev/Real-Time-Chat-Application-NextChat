import React from 'react';
import { useToastProvider } from '../hooks/useToast';
export default function Toast() {
  const toasts = useToastProvider();
  if (!toasts.length) return null;
  return (
    <div style={{ position:'fixed',bottom:24,left:'50%',transform:'translateX(-50%)',zIndex:9999,display:'flex',flexDirection:'column',gap:8,alignItems:'center' }}>
      {toasts.map(t => (
        <div key={t.id} style={{ background: t.type==='error'?'#ef4444':t.type==='success'?'#22c55e':'#1e293b', color:'#fff', padding:'10px 20px', borderRadius:12, fontSize:14, boxShadow:'0 4px 24px rgba(0,0,0,0.4)', animation:'slideUp .2s ease', whiteSpace:'nowrap' }}>
          {t.msg}
        </div>
      ))}
    </div>
  );
}
