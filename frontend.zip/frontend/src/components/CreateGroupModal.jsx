import React, { useState } from 'react';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function CreateGroupModal({ contacts, onClose, onCreated }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [selected, setSelected] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const toggle = (id) => {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleCreate = async () => {
    if (!name.trim()) return setError('Group name required');
    if (selected.length < 1) return setError('Select at least 1 member');
    setLoading(true); setError('');
    try {
      const res = await axios.post(`${API}/groups/create`, { name, description, members: selected });
      onCreated(res.data);
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to create group');
    }
    setLoading(false);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ maxHeight: '80vh', overflowY: 'auto' }}>
        <div className="modal-title">
          👥 New Group
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: 20 }}>✕</button>
        </div>

        {error && <div className="error-msg">⚠️ {error}</div>}

        <div className="form-group">
          <label className="form-label">Group Name</label>
          <input className="form-input" placeholder="Enter group name" value={name} onChange={e => setName(e.target.value)} />
        </div>

        <div className="form-group">
          <label className="form-label">Description (optional)</label>
          <input className="form-input" placeholder="What's this group about?" value={description} onChange={e => setDescription(e.target.value)} />
        </div>

        <div className="form-group">
          <label className="form-label">Add Members ({selected.length} selected)</label>
          <div className="group-members-list">
            {contacts.map(c => (
              <div key={c._id} className="member-item" style={{ cursor: 'pointer' }} onClick={() => toggle(c._id)}>
                <div style={{
                  width: 20, height: 20, borderRadius: 6,
                  background: selected.includes(c._id) ? '#00b4d8' : 'rgba(255,255,255,0.1)',
                  border: '2px solid ' + (selected.includes(c._id) ? '#00b4d8' : 'rgba(255,255,255,0.2)'),
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, flexShrink: 0
                }}>
                  {selected.includes(c._id) && '✓'}
                </div>
                {c.avatar
                  ? <img src={c.avatar} alt="" style={{ width: 36, height: 36, borderRadius: '50%', objectFit: 'cover' }} />
                  : <div className="avatar-placeholder" style={{ width: 36, height: 36, fontSize: 14 }}>{c.name?.[0]?.toUpperCase()}</div>
                }
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{c.name}</div>
                  <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)' }}>{c.phone}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button className="btn-primary" onClick={handleCreate} disabled={loading}>
          {loading ? 'Creating...' : '✓ Create Group'}
        </button>
      </div>
    </div>
  );
}
