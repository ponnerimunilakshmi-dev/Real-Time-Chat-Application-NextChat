import React, { useEffect, useRef } from 'react';
export default function ReactionPicker({ emojis, onPick, onClose, isSent }) {
  const ref = useRef();
  useEffect(() => {
    const h = (e) => { if (!ref.current?.contains(e.target)) onClose(); };
    setTimeout(() => document.addEventListener('click', h), 50);
    return () => document.removeEventListener('click', h);
  }, [onClose]);
  return (
    <div ref={ref} className="rxn-picker" style={{ [isSent ? 'right' : 'left']: 0 }}>
      {emojis.map(e => <button key={e} className="rxn-opt" onClick={() => onPick(e)}>{e}</button>)}
    </div>
  );
}
