import React from 'react';
export default function LinkPreview({ preview }) {
  if (!preview?.url) return null;
  return (
    <a className="link-preview" href={preview.url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}>
      {preview.image && <img src={preview.image} alt="" className="link-preview-img" onError={e => e.target.style.display = 'none'} />}
      {preview.title && <div className="link-preview-title">{preview.title}</div>}
      {preview.description && <div className="link-preview-desc">{preview.description}</div>}
      <div className="link-preview-domain">🔗 {preview.domain}</div>
    </a>
  );
}
