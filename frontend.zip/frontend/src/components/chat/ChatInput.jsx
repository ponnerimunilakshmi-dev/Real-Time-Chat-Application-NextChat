import React, { useState, useRef, useEffect } from 'react';
import EmojiPicker from 'emoji-picker-react';
import axios from 'axios';
import { useSocket } from '../../context/SocketContext';
import { useChat } from '../../context/ChatContext';
import { showToast } from '../../hooks/useToast';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const STICKERS = ['😂','🤣','❤️','😍','🥰','😎','🤩','🥳','😭','😢','😡','🤬','😱','🤯','🥺','😏','👏','🙌','🤝','👍','👎','🐶','🐱','🦁','🐸','🎉','🎊','🔥','💥','✨','🌟','🍕','🍔','🎮','💎'];

export default function ChatInput({ activeChat, replyTo, onClearReply, editingMsg, onClearEdit, colors, onOpenPoll, onOpenSchedule, onOpenGif }) {
  const { socket } = useSocket();
  const { sendMessage, editMessage } = useChat();
  const [text, setText] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const [showStickers, setShowStickers] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recDuration, setRecDuration] = useState(0);
  const fileRef = useRef();
  const textRef = useRef();
  const mediaRecorderRef = useRef();
  const recTimerRef = useRef();
  const typingTimerRef = useRef();

  useEffect(() => {
    if (editingMsg) { setText(editingMsg.content || ''); textRef.current?.focus(); }
  }, [editingMsg]);

  const handleTyping = (e) => {
    setText(e.target.value);
    if (activeChat?.chatType === 'user') {
      socket?.emit('typing:start', { to: activeChat._id });
      clearTimeout(typingTimerRef.current);
      typingTimerRef.current = setTimeout(() => socket?.emit('typing:stop', { to: activeChat._id }), 1500);
    }
    // Auto-resize
    const t = textRef.current;
    if (t) { t.style.height = 'auto'; t.style.height = Math.min(t.scrollHeight, 100) + 'px'; }
  };

  const handleSend = () => {
    const txt = text.trim();
    if (!txt && !editingMsg) return;
    if (editingMsg) {
      editMessage(editingMsg._id, txt);
      onClearEdit?.();
    } else {
      sendMessage({ type: 'text', content: txt, replyTo: replyTo?._id });
    }
    setText('');
    if (textRef.current) { textRef.current.style.height = 'auto'; }
    onClearReply?.();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleFile = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    const type = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : file.type.startsWith('audio/') ? 'audio' : 'document';
    showToast('📤 Uploading...');
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('type', type);
      if (activeChat.chatType === 'user') fd.append('receiver', activeChat._id); else fd.append('group', activeChat._id);
      const res = await axios.post(`${API}/messages/upload`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      sendMessage({ ...res.data, _fromUpload: true });
      showToast('✅ Sent!');
    } catch (err) { showToast('❌ Upload failed', 'error'); }
    e.target.value = '';
  };

  const startVoice = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks = [];
      recorder.ondataavailable = e => chunks.push(e.data);
      recorder.onstop = async () => {
        clearInterval(recTimerRef.current);
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const fd = new FormData(); fd.append('file', new File([blob], 'voice.webm', { type: 'audio/webm' })); fd.append('type', 'audio');
        if (activeChat.chatType === 'user') fd.append('receiver', activeChat._id); else fd.append('group', activeChat._id);
        try { const res = await axios.post(`${API}/messages/upload`, fd, { headers: { 'Content-Type': 'multipart/form-data' } }); sendMessage({ ...res.data, _fromUpload: true }); }
        catch (err) { showToast('❌ Voice send failed', 'error'); }
        stream.getTracks().forEach(t => t.stop());
        setRecording(false); setRecDuration(0);
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setRecording(true); setRecDuration(0);
      recTimerRef.current = setInterval(() => setRecDuration(d => d + 1), 1000);
    } catch { showToast('🎤 Microphone access denied', 'error'); }
  };

  const stopVoice = () => { mediaRecorderRef.current?.stop(); };

  return (
    <div className="chat-input-area" style={{ background: `${colors?.sidebar || '#111827'}ee` }}>
      {(replyTo || editingMsg) && (
        <div className="reply-bar">
          <div style={{ borderLeft: '3px solid #00b4d8', paddingLeft: 10 }}>
            <div style={{ fontSize: 12, color: '#00b4d8', fontWeight: 600 }}>
              {editingMsg ? '✏️ Editing' : `↩️ ${replyTo?.sender?.name || 'Reply'}`}
            </div>
            <div style={{ fontSize: 12, opacity: 0.6 }}>{(editingMsg || replyTo)?.content?.slice(0, 60) || '📎 Media'}</div>
          </div>
          <button onClick={() => { onClearReply?.(); onClearEdit?.(); }} className="reply-close">✕</button>
        </div>
      )}

      {recording ? (
        <div className="recording-bar">
          <div className="rec-dot" />
          <span>Recording {Math.floor(recDuration / 60).toString().padStart(2,'0')}:{(recDuration % 60).toString().padStart(2,'0')}</span>
          <button className="rec-cancel" onClick={() => { mediaRecorderRef.current?.stop(); setRecording(false); setRecDuration(0); clearInterval(recTimerRef.current); }}>✕ Cancel</button>
          <button className="send-btn" onClick={stopVoice} style={{ marginLeft: 'auto' }}>✅ Send</button>
        </div>
      ) : (
        <div className="input-row">
          <div className="input-actions">
            <button className="icon-btn" title="Emoji" onClick={() => { setShowEmoji(v => !v); setShowStickers(false); }}>😊</button>
            <button className="icon-btn" title="Stickers" onClick={() => { setShowStickers(v => !v); setShowEmoji(false); }}>🎭</button>
            <button className="icon-btn" title="GIF" onClick={() => { onOpenGif?.(); setShowEmoji(false); setShowStickers(false); }}>🎞️</button>
            <button className="icon-btn" title="Poll" onClick={onOpenPoll}>📊</button>
            <button className="icon-btn" title="Schedule" onClick={onOpenSchedule}>⏰</button>
            <button className="icon-btn" title="Attach" onClick={() => fileRef.current?.click()}>📎</button>
            <input ref={fileRef} type="file" hidden accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt,.zip" onChange={handleFile} />
          </div>
          <textarea
            ref={textRef}
            className="chat-input"
            placeholder={editingMsg ? 'Edit message...' : 'Type a message...'}
            value={text}
            onChange={handleTyping}
            onKeyDown={handleKeyDown}
            rows={1}
          />
          <button className="icon-btn" title="Hold to record" onMouseDown={startVoice} onMouseUp={stopVoice} style={{ color: recording ? '#ef4444' : undefined }}>🎤</button>
          <button className="send-btn" onClick={handleSend} disabled={!text.trim() && !editingMsg}>➤</button>
        </div>
      )}

      {showEmoji && (
        <div className="emoji-picker-wrap" onClick={e => e.stopPropagation()}>
          <EmojiPicker theme="dark" onEmojiClick={e => { setText(p => p + e.emoji); setShowEmoji(false); }} height={380} width={320} />
        </div>
      )}
      {showStickers && (
        <div className="sticker-panel" onClick={e => e.stopPropagation()}>
          {STICKERS.map((s, i) => (
            <div key={i} className="sticker-item" onClick={() => { sendMessage({ type: 'sticker', sticker: s, content: s }); setShowStickers(false); }}>{s}</div>
          ))}
        </div>
      )}
    </div>
  );
}
