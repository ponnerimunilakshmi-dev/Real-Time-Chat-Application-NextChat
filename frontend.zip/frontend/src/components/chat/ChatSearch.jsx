import React, { useState, useEffect } from 'react';
import { useChat } from '../../context/ChatContext';
export default function ChatSearch({ onClose }) {
  const { activeChat, messages } = useChat();
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    if (!q.trim()) { setResults([]); return; }
    const msgs = (messages[activeChat?._id] || []).filter(m => m.content?.toLowerCase().includes(q.toLowerCase()) && !m.deletedForEveryone);
    setResults(msgs); setIdx(msgs.length - 1);
    if (msgs.length) scrollTo(msgs[msgs.length - 1]._id);
  }, [q]);
  const scrollTo = (id) => { const el = document.getElementById(`msg-${id}`); el?.scrollIntoView({ behavior: 'smooth', block: 'center' }); };
  const nav = (d) => {
    const ni = Math.max(0, Math.min(results.length - 1, idx + d));
    setIdx(ni); if (results[ni]) scrollTo(results[ni]._id);
  };
  return (
    <div className="chat-search-bar">
      <input autoFocus className="chat-search-input" placeholder="Search in chat..." value={q} onChange={e => setQ(e.target.value)} />
      <button className="search-nav" onClick={() => nav(-1)}>↑</button>
      <button className="search-nav" onClick={() => nav(1)}>↓</button>
      <span style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', minWidth: 50, textAlign: 'center' }}>{results.length ? `${idx + 1}/${results.length}` : q ? '0 results' : ''}</span>
      <button className="search-nav" onClick={onClose}>✕</button>
    </div>
  );
}
