import React from 'react';
import { useAuth } from '../../context/AuthContext';
export default function PollMessage({ msg, isSent, onVote }) {
  const { user } = useAuth();
  const { poll } = msg;
  if (!poll) return null;
  const total = poll.options.reduce((s, o) => s + (o.votes?.length || 0), 0);
  return (
    <div className="poll-wrap">
      <div className="poll-question">📊 {poll.question}</div>
      {poll.options.map((opt, i) => {
        const voted = opt.votes?.some(id => (id?._id || id) === user._id);
        const pct = total > 0 ? Math.round((opt.votes?.length || 0) / total * 100) : 0;
        return (
          <div key={i} className={`poll-option ${voted ? 'voted' : ''}`} onClick={() => onVote(i)}>
            <div className="poll-bar" style={{ width: pct + '%' }} />
            <div className="poll-label">
              <span>{opt.text}</span>
              <span>{opt.votes?.length || 0} ({pct}%)</span>
            </div>
          </div>
        );
      })}
      <div className="poll-total">{total} vote{total !== 1 ? 's' : ''}</div>
    </div>
  );
}
