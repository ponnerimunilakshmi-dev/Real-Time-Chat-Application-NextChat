import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useChat } from '../../context/ChatContext';
import ReactionPicker from './ReactionPicker';
import PollMessage from './PollMessage';
import LinkPreview from './LinkPreview';

const REACTION_EMOJIS = ['❤️','😂','😮','😢','😡','👍','👎','🔥'];
const fmt = d => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

export default function MessageBubble({ msg, onReply, onEdit, onDelete, onForward, colors, isHighlighted }) {
  const { user } = useAuth();
  const { reactToMessage, starMessage, votePoll } = useChat();
  const [showRxn, setShowRxn] = useState(false);
  const [showCtx, setShowCtx] = useState(false);
  const [ctxPos, setCtxPos] = useState({ x: 0, y: 0 });

  const isSent = (msg.sender?._id || msg.sender) === user._id;
  const isDeleted = msg.deletedForEveryone;

  const grouped = {};
  (msg.reactions || []).forEach(r => {
    const e = r.emoji;
    if (!grouped[e]) grouped[e] = { count: 0, mine: false };
    grouped[e].count++;
    if ((r.user?._id || r.user) === user._id) grouped[e].mine = true;
  });

  const handleContext = (e) => {
    e.preventDefault();
    if (isDeleted) return;
    setCtxPos({ x: Math.min(e.clientX, window.innerWidth - 180), y: Math.min(e.clientY, window.innerHeight - 280) });
    setShowCtx(true);
  };

  const ticks = () => {
    if (!isSent) return null;
    const isRead = msg.read || (msg.readBy?.length > 1);
    return <span style={{ marginLeft: 4, fontSize: 11, color: isRead ? '#00b4d8' : 'rgba(255,255,255,0.4)' }}>{isRead ? '✓✓' : '✓'}</span>;
  };

  return (
    <>
      <div
        id={`msg-${msg._id}`}
        className={`message-row ${isSent ? 'sent' : 'received'} ${isHighlighted ? 'highlighted' : ''}`}
        onContextMenu={handleContext}
      >
        {!isSent && (
          <div className="avatar-sm">
            {msg.sender?.avatar
              ? <img src={msg.sender.avatar} alt="" style={{ width: 28, height: 28, borderRadius: '50%', objectFit: 'cover' }} />
              : <div className="avatar-placeholder" style={{ width: 28, height: 28, fontSize: 11 }}>{(msg.sender?.name || '?')[0].toUpperCase()}</div>
            }
          </div>
        )}

        <div style={{ maxWidth: '62%', position: 'relative' }}>
          {/* Reaction picker trigger */}
          {!isDeleted && (
            <button
              className="rxn-trigger"
              style={{ [isSent ? 'left' : 'right']: -30, [isSent ? 'right' : 'left']: 'auto' }}
              onClick={() => setShowRxn(v => !v)}
              onMouseDown={e => e.stopPropagation()}
            >😊</button>
          )}
          {showRxn && (
            <ReactionPicker
              emojis={REACTION_EMOJIS}
              onPick={(emoji) => { reactToMessage(msg._id, emoji); setShowRxn(false); }}
              onClose={() => setShowRxn(false)}
              isSent={isSent}
            />
          )}

          <div
            className={`message-bubble ${isSent ? 'sent' : 'received'} ${isDeleted ? 'deleted' : ''}`}
            style={isSent && !isDeleted ? { background: colors?.bubble || '#00b4d8', color: colors?.bubbleText || '#fff' } : {}}
          >
            {/* Forwarded label */}
            {msg.isForwarded && <div className="fwd-label">↪️ Forwarded</div>}

            {/* Reply preview */}
            {msg.replyTo && !isDeleted && (
              <div className="reply-preview-bubble" onClick={() => {
                const el = document.getElementById(`msg-${msg.replyTo?._id || msg.replyTo}`);
                el?.scrollIntoView({ behavior: 'smooth', block: 'center' });
                el?.classList.add('highlighted');
                setTimeout(() => el?.classList.remove('highlighted'), 2000);
              }}>
                <div className="reply-sender">{msg.replyTo?.sender?.name || 'Message'}</div>
                <div className="reply-content">{msg.replyTo?.content || '📎 Media'}</div>
              </div>
            )}

            {/* Message content */}
            {isDeleted ? (
              <div className="msg-text deleted-text">🚫 This message was deleted</div>
            ) : msg.type === 'sticker' ? (
              <div style={{ fontSize: 48, lineHeight: 1 }}>{msg.sticker || msg.content}</div>
            ) : msg.type === 'gif' || msg.gifUrl ? (
              <img src={msg.gifUrl || msg.mediaUrl} alt="GIF" className="msg-img" onClick={() => window.open(msg.gifUrl || msg.mediaUrl, '_blank')} />
            ) : msg.type === 'image' && msg.mediaUrl ? (
              <div>
                <img src={msg.mediaUrl} alt="" className="msg-img" onClick={() => window.open(msg.mediaUrl, '_blank')} />
                {msg.content && <div className="msg-text" style={{ marginTop: 6 }}>{msg.content}</div>}
              </div>
            ) : msg.type === 'video' && msg.mediaUrl ? (
              <video controls className="msg-video" src={msg.mediaUrl} />
            ) : msg.type === 'audio' && msg.mediaUrl ? (
              <div className="msg-audio-wrap">
                <span>🎤</span>
                <audio controls src={msg.mediaUrl} style={{ maxWidth: 200 }} />
              </div>
            ) : msg.type === 'document' && msg.mediaUrl ? (
              <a className="msg-doc" href={msg.mediaUrl} target="_blank" rel="noopener noreferrer">
                <span style={{ fontSize: 28 }}>📄</span>
                <div><div style={{ fontWeight: 600, fontSize: 13 }}>{msg.mediaName || 'Document'}</div><div style={{ fontSize: 11, opacity: 0.6 }}>{msg.mediaSize ? `${Math.round(msg.mediaSize / 1024)} KB` : 'Open'}</div></div>
              </a>
            ) : msg.type === 'poll' && msg.poll ? (
              <PollMessage msg={msg} isSent={isSent} onVote={(i) => votePoll(msg._id, i)} />
            ) : msg.type === 'link' && msg.linkPreview?.url ? (
              <div>
                <div className="msg-text">{msg.content}</div>
                <LinkPreview preview={msg.linkPreview} />
              </div>
            ) : (
              <div className="msg-text">{msg.content}</div>
            )}

            {/* Edited + Time + Ticks + Star */}
            {!isDeleted && (
              <div className="msg-meta">
                {msg.isEdited && <span className="edit-badge">edited</span>}
                {msg.isStarred && <span style={{ fontSize: 10 }}>⭐</span>}
                <span className="msg-time">{fmt(msg.createdAt)}</span>
                {ticks()}
              </div>
            )}
          </div>

          {/* Reactions bar */}
          {Object.keys(grouped).length > 0 && (
            <div className={`reactions-bar ${isSent ? 'sent' : ''}`}>
              {Object.entries(grouped).map(([emoji, { count, mine }]) => (
                <button
                  key={emoji}
                  className={`rxn-badge ${mine ? 'mine' : ''}`}
                  onClick={() => reactToMessage(msg._id, emoji)}
                >
                  {emoji} <span>{count}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Context menu */}
      {showCtx && (
        <div className="ctx-menu" style={{ top: ctxPos.y, left: ctxPos.x }} onClick={() => setShowCtx(false)}>
          <div className="ctx-item" onClick={() => onReply(msg)}>↩️ Reply</div>
          {isSent && msg.type === 'text' && <div className="ctx-item" onClick={() => onEdit(msg)}>✏️ Edit</div>}
          <div className="ctx-item" onClick={() => onForward(msg)}>↪️ Forward</div>
          <div className="ctx-item" onClick={() => { starMessage(msg._id); }}>⭐ {msg.isStarred ? 'Unstar' : 'Star'}</div>
          <div className="ctx-item" onClick={() => navigator.clipboard?.writeText(msg.content || '')}>📋 Copy</div>
          <div className="ctx-divider" />
          <div className="ctx-item danger" onClick={() => onDelete(msg, isSent)}>🗑️ Delete</div>
        </div>
      )}
    </>
  );
}
