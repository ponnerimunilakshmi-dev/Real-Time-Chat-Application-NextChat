import React from 'react';
import { useSocket } from '../../context/SocketContext';
import { useChat } from '../../context/ChatContext';
import { getContactSettings, PRESET_THEMES } from '../modals/ContactSettingsModal';
const fmt = d => { if (!d) return ''; try { const t = new Date(d); const now = new Date(); if (now - t < 86400000) return t.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); return t.toLocaleDateString(); } catch { return ''; } };
export default function ConversationItem({ item, type, isActive, onOpen, onContextMenu }) {
  const { onlineUsers } = useSocket();
  const { messages, unreadCounts, pinnedIds, mutedIds } = useChat();
  const msgs = messages[item._id] || [];
  const last = msgs[msgs.length - 1];
  const unread = unreadCounts[item._id] || 0;
  const isOnline = type === 'user' && onlineUsers.has(item._id);
  const isPinned = pinnedIds.includes(item._id);
  const isMuted = mutedIds.includes(item._id);
  const preview = last ? (last.deletedForEveryone ? '🚫 Deleted' : last.type === 'sticker' ? last.sticker : last.type === 'image' ? '📷 Photo' : last.type === 'video' ? '🎬 Video' : last.type === 'audio' ? '🎤 Voice' : last.type === 'gif' ? '🎞️ GIF' : last.type === 'poll' ? '📊 Poll' : last.type === 'document' ? '📄 Document' : last.content || '') : item.about || '';

  // Per-contact theme accent
  const contactSettings = type === 'user' ? getContactSettings(item._id) : null;
  const hasCustomTheme = contactSettings && contactSettings.theme && contactSettings.theme !== 'default';
  const themeAccent = hasCustomTheme && contactSettings.theme !== 'custom'
    ? PRESET_THEMES[contactSettings.theme]?.bubble
    : null;

  return (
    <div className={`conv-item ${isActive ? 'active' : ''}`} onClick={onOpen} onContextMenu={onContextMenu}>
      <div style={{ position: 'relative', flexShrink: 0 }}>
        {item.avatar ? <img src={item.avatar} alt="" className="conv-avatar" /> : <div className="conv-avatar placeholder">{item.name?.[0]?.toUpperCase()}</div>}
        {isOnline && <div className="online-dot" />}
        {themeAccent && !isOnline && (
          <div style={{ position: 'absolute', bottom: 1, right: 1, width: 10, height: 10, borderRadius: '50%', background: themeAccent, border: '2px solid var(--sidebar,#111827)' }} title="Custom theme" />
        )}
      </div>
      <div className="conv-body">
        <div className="conv-top">
          <span className="conv-name">{isPinned && <span>📌 </span>}{item.name}{item.username && <span className="username-tag"> @{item.username}</span>}{isMuted && <span style={{ opacity: 0.4 }}> 🔕</span>}</span>
          <span className="conv-time">{fmt(last?.createdAt)}</span>
        </div>
        <div className="conv-bottom">
          <span className="conv-preview">{preview}</span>
          {unread > 0 && <span className="unread-badge" style={themeAccent ? { background: themeAccent } : {}}>{unread > 99 ? '99+' : unread}</span>}
        </div>
      </div>
    </div>
  );
}
