import React, { useRef } from 'react';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const THEME_NAMES = {
  dark: { label: 'Dark', colors: ['#0a0f1e', '#00b4d8'] },
  light: { label: 'Light', colors: ['#f0f2f5', '#25d366'] },
  ocean: { label: 'Ocean', colors: ['#0a1628', '#0077b6'] },
  forest: { label: 'Forest', colors: ['#0d1f0d', '#40916c'] },
  sunset: { label: 'Sunset', colors: ['#1a0a0a', '#e63946'] },
  purple: { label: 'Purple', colors: ['#0d0720', '#9b59b6'] }
};

export default function ThemeModal({ onClose }) {
  const { updateUser } = useAuth();
  const { currentTheme, applyPreset, applyCustomBg } = useTheme();
  const fileRef = useRef();

  const handlePreset = async (name) => {
    applyPreset(name);
    try {
      const res = await axios.put(`${API}/users/theme`, { theme: { type: 'preset', value: name } });
      updateUser({ theme: res.data.theme });
    } catch (e) { console.error(e); }
  };

  const handleCustomUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const preview = URL.createObjectURL(file);
    applyCustomBg(preview);

    try {
      const formData = new FormData();
      formData.append('themeImage', file);
      const res = await axios.post(`${API}/users/theme/custom`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      applyCustomBg(res.data.themeUrl);
      updateUser({ theme: res.data.user.theme });
    } catch (e) { console.error(e); }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title">
          🎨 Chat Theme
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: 20 }}>✕</button>
        </div>

        <div style={{ marginBottom: 16, fontSize: 13, color: 'rgba(255,255,255,0.4)' }}>
          Theme applies only to your account
        </div>

        <div className="theme-grid">
          {Object.entries(THEME_NAMES).map(([key, { label, colors }]) => (
            <div
              key={key}
              className={`theme-swatch ${currentTheme === key ? 'active' : ''}`}
              style={{ background: `linear-gradient(135deg, ${colors[0]} 0%, ${colors[1]} 100%)` }}
              onClick={() => handlePreset(key)}
            >
              <span>{label}</span>
            </div>
          ))}
        </div>

        <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: 16 }}>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.5)', marginBottom: 12 }}>
            Custom background photo
          </div>
          <button
            className="btn-secondary"
            style={{ width: '100%' }}
            onClick={() => fileRef.current?.click()}
          >
            📷 Upload Your Photo as Background
          </button>
          <input ref={fileRef} type="file" hidden accept="image/*" onChange={handleCustomUpload} />

          {currentTheme === 'custom' && (
            <div style={{ marginTop: 10, fontSize: 12, color: '#22c55e' }}>
              ✓ Custom background applied
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
