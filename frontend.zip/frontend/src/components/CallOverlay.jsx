import React, { useState, useEffect } from 'react';
export default function CallOverlay({ callState, localVideoRef, remoteVideoRef, onAnswer, onEnd, onReject, onShareScreen }) {
  const [muted, setMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  useEffect(() => {
    if (callState?.status !== 'active') return;
    const t = setInterval(() => setDuration(d => d + 1), 1000);
    return () => clearInterval(t);
  }, [callState?.status]);
  const fmt = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  const isIncoming = callState?.status === 'incoming';
  const isActive = callState?.status === 'active';
  return (
    <div className="call-overlay">
      {callState?.type === 'video' && (
        <div className="call-video-area">
          <video ref={remoteVideoRef} autoPlay playsInline className="remote-video" />
          <video ref={localVideoRef} autoPlay playsInline muted className="local-video" />
        </div>
      )}
      <div className="call-info">
        <div className="call-avatar">{callState?.peer?.name?.[0]?.toUpperCase()}</div>
        <div className="call-name">{callState?.peer?.name}</div>
        <div className="call-status">
          {isIncoming ? `${callState.type === 'video' ? '📹' : '📞'} Incoming ${callState.type} call`
            : isActive ? `${callState.type === 'video' ? '📹' : '📞'} ${fmt(duration)}`
            : 'Calling...'}
        </div>
      </div>
      <div className="call-actions">
        {isIncoming && <button className="call-btn ans" onClick={onAnswer}>📞</button>}
        {isIncoming && <button className="call-btn rej" onClick={onReject}>📵</button>}
        {!isIncoming && <button className={`call-btn ${muted ? 'active' : ''}`} onClick={() => setMuted(v => !v)}>{muted ? '🔇' : '🎤'}</button>}
        {!isIncoming && callState?.type === 'video' && <button className="call-btn" onClick={onShareScreen}>📺</button>}
        {!isIncoming && <button className="call-btn end" onClick={onEnd}>📵</button>}
      </div>
    </div>
  );
}
