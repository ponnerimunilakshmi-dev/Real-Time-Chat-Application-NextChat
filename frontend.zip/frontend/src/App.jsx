import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { ThemeProvider } from './context/ThemeContext';
import { ChatProvider } from './context/ChatContext';
import Login from './pages/Login';
import Register from './pages/Register';
import Chat from './pages/Chat';
import './styles/global.css';

const PrivateRoute = ({ children }) => { const { user } = useAuth(); return user ? children : <Navigate to="/login" />; };
const PublicRoute  = ({ children }) => { const { user } = useAuth(); return !user ? children : <Navigate to="/" />; };

function AppRoutes() {
  return (
    <ThemeProvider>
      <SocketProvider>
        <ChatProvider>
          <Routes>
            <Route path="/login"    element={<PublicRoute><Login /></PublicRoute>} />
            <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />
            <Route path="/"         element={<PrivateRoute><Chat /></PrivateRoute>} />
            <Route path="*"         element={<Navigate to="/" />} />
          </Routes>
        </ChatProvider>
      </SocketProvider>
    </ThemeProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}
