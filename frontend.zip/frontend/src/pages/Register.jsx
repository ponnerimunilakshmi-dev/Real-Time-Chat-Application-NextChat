import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const STEPS = { PHONE: 0, VERIFY: 1, DETAILS: 2 };

export default function Register() {
  const { sendOTP, verifyOTP, register } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(STEPS.PHONE);
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [timer, setTimer] = useState(0);

  const startTimer = () => {
    setTimer(60);
    const i = setInterval(() => setTimer(t => { if (t <= 1) { clearInterval(i); return 0; } return t - 1; }), 1000);
  };

  const handleSendOTP = async () => {
    if (!phone || phone.length < 10) return setError('Enter a valid 10-digit phone number');
    setLoading(true); setError('');
    try {
      const result = await sendOTP(phone);
      setStep(STEPS.VERIFY);
      startTimer();
      // Dev mode or SMS failure fallback - auto fill OTP
      if (result.devOtp) {
        setOtp(result.devOtp.toString().split(''));
        setError('SMS unavailable. OTP auto-filled: ' + result.devOtp);
      }
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to send OTP. Check your API key.');
    }
    setLoading(false);
  };

  const handleOTPChange = (val, idx) => {
    const newOtp = [...otp];
    newOtp[idx] = val.slice(-1);
    setOtp(newOtp);
    if (val && idx < 5) {
      document.getElementById(`otp-${idx + 1}`)?.focus();
    }
  };

  const handleOTPKeyDown = (e, idx) => {
    if (e.key === 'Backspace' && !otp[idx] && idx > 0) {
      document.getElementById(`otp-${idx - 1}`)?.focus();
    }
  };

  const handleVerifyOTP = async () => {
    const otpStr = otp.join('');
    if (otpStr.length < 6) return setError('Enter full 6-digit OTP');
    setLoading(true); setError('');
    try {
      await verifyOTP(phone, otpStr);
      setStep(STEPS.DETAILS);
    } catch (e) {
      setError(e.response?.data?.message || 'Invalid OTP');
    }
    setLoading(false);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    if (!name.trim()) return setError('Name is required');
    if (password.length < 6) return setError('Password must be at least 6 characters');
    setLoading(true); setError('');
    try {
      await register(name, phone, password);
      navigate('/');
    } catch (e) {
      setError(e.response?.data?.message || 'Registration failed');
    }
    setLoading(false);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="logo">NexChat</div>
        <div className="logo-sub">Create your account</div>

        {/* Step indicator */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginBottom: 28 }}>
          {['Phone', 'Verify', 'Profile'].map((s, i) => (
            <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%',
                background: i <= step ? '#00b4d8' : 'rgba(255,255,255,0.1)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, fontWeight: 700, color: '#fff', transition: 'all 0.3s'
              }}>
                {i < step ? '✓' : i + 1}
              </div>
              <span style={{ fontSize: 12, color: i === step ? '#00b4d8' : 'rgba(255,255,255,0.3)' }}>{s}</span>
              {i < 2 && <div style={{ width: 20, height: 1, background: 'rgba(255,255,255,0.1)' }} />}
            </div>
          ))}
        </div>

        {error && <div className="error-msg">⚠️ {error}</div>}

        {step === STEPS.PHONE && (
          <div>
            <div className="form-group">
              <label className="form-label">Phone Number</label>
              <input
                className="form-input"
                type="tel"
                placeholder="Enter your mobile number"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSendOTP()}
              />
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.3)', marginTop: 6 }}>
                We'll send an OTP to verify your number
              </div>
            </div>
            <button className="btn-primary" onClick={handleSendOTP} disabled={loading}>
              {loading ? '⏳ Sending OTP...' : '📱 Send OTP to Mobile'}
            </button>
            <p style={{ textAlign: 'center', marginTop: 20, color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>
              Already have an account?{' '}
              <Link to="/login" style={{ color: '#00b4d8', textDecoration: 'none', fontWeight: 600 }}>Login</Link>
            </p>
          </div>
        )}

        {step === STEPS.VERIFY && (
          <div>
            <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.5)', marginBottom: 4, fontSize: 14 }}>
              OTP sent to <strong style={{ color: '#00b4d8' }}>{phone}</strong>
            </p>
            <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.3)', marginBottom: 16, fontSize: 13 }}>
              Enter the 6-digit code from your SMS
            </p>

            <div className="otp-input-row">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  id={`otp-${i}`}
                  className="otp-digit"
                  type="text"
                  maxLength={1}
                  value={digit}
                  onChange={e => handleOTPChange(e.target.value, i)}
                  onKeyDown={e => handleOTPKeyDown(e, i)}
                  inputMode="numeric"
                />
              ))}
            </div>

            <div className="timer-text" style={{ marginBottom: 16 }}>
              {timer > 0 ? `Resend OTP in ${timer}s` :
                <button className="link-btn" onClick={handleSendOTP}>Resend OTP</button>}
            </div>

            <button className="btn-primary" onClick={handleVerifyOTP} disabled={loading || otp.join('').length < 6}>
              {loading ? '⏳ Verifying...' : 'Verify OTP'}
            </button>
            <button onClick={() => { setStep(STEPS.PHONE); setOtp(['','','','','','']); setError(''); }}
              style={{ width: '100%', marginTop: 10 }} className="btn-secondary">
              ← Change Number
            </button>
          </div>
        )}

        {step === STEPS.DETAILS && (
          <form onSubmit={handleRegister}>
            <div style={{ textAlign: 'center', marginBottom: 20 }}>
              <span style={{ fontSize: 24 }}>✅</span>
              <div style={{ color: '#86efac', fontSize: 14, marginTop: 4 }}>Phone verified!</div>
            </div>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                className="form-input"
                type="text"
                placeholder="What should we call you?"
                value={name}
                onChange={e => setName(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                placeholder="Create a strong password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                minLength={6}
                required
              />
            </div>
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? '⏳ Creating Account...' : '🚀 Create Account'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
