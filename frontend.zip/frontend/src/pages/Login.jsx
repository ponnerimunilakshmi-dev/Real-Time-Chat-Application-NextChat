import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { login, loginWithOTP, sendOTP } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState('password'); // 'password' or 'otp'
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);

  const startTimer = () => {
    setOtpTimer(60);
    const interval = setInterval(() => {
      setOtpTimer(t => {
        if (t <= 1) { clearInterval(interval); return 0; }
        return t - 1;
      });
    }, 1000);
  };

  const handleSendOTP = async () => {
    if (!phone || phone.length < 10) return setError('Enter valid phone number');
    setLoading(true);
    setError('');
    try {
      const result = await sendOTP(phone);
      setOtpSent(true);
      startTimer();
      if (result.devOtp) {
        setOtp(result.devOtp.toString());
        setError('SMS unavailable — OTP auto-filled: ' + result.devOtp);
      }
    } catch (e) {
      setError(e.response?.data?.message || 'Failed to send OTP');
    }
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'password') {
        await login(phone, password);
      } else {
        await loginWithOTP(phone, otp);
      }
      navigate('/');
    } catch (e) {
      setError(e.response?.data?.message || 'Login failed');
    }
    setLoading(false);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="logo">NexChat</div>
        <div className="logo-sub">Connect without limits</div>

        <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
          <button
            className="btn-secondary"
            style={{ flex: 1, background: mode === 'password' ? 'rgba(0,180,216,0.15)' : '', borderColor: mode === 'password' ? '#00b4d8' : '', color: mode === 'password' ? '#00b4d8' : '' }}
            onClick={() => setMode('password')}
          >🔑 Password</button>
          <button
            className="btn-secondary"
            style={{ flex: 1, background: mode === 'otp' ? 'rgba(0,180,216,0.15)' : '', borderColor: mode === 'otp' ? '#00b4d8' : '', color: mode === 'otp' ? '#00b4d8' : '' }}
            onClick={() => { setMode('otp'); setOtpSent(false); }}
          >📱 OTP Login</button>
        </div>

        {error && <div className="error-msg">⚠️ {error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input
              className="form-input"
              type="tel"
              placeholder="Enter your phone number"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
            />
          </div>

          {mode === 'password' && (
            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                className="form-input"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
              />
            </div>
          )}

          {mode === 'otp' && (
            <>
              {!otpSent ? (
                <button type="button" className="btn-primary" onClick={handleSendOTP} disabled={loading}>
                  {loading ? 'Sending...' : 'Send OTP to Mobile'}
                </button>
              ) : (
                <>
                  <div className="form-group">
                    <label className="form-label">Enter OTP sent to {phone}</label>
                    <input
                      className="form-input"
                      type="text"
                      placeholder="6-digit OTP"
                      maxLength={6}
                      value={otp}
                      onChange={e => setOtp(e.target.value)}
                    />
                    <div className="timer-text">
                      {otpTimer > 0 ? `Resend in ${otpTimer}s` :
                        <button type="button" className="link-btn" onClick={handleSendOTP}>Resend OTP</button>}
                    </div>
                  </div>
                  <button type="submit" className="btn-primary" disabled={loading || otp.length < 6}>
                    {loading ? 'Verifying...' : 'Login with OTP'}
                  </button>
                </>
              )}
            </>
          )}

          {mode === 'password' && (
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </button>
          )}
        </form>

        <p style={{ textAlign: 'center', marginTop: 20, color: 'rgba(255,255,255,0.4)', fontSize: 14 }}>
          Don't have an account?{' '}
          <Link to="/register" style={{ color: '#00b4d8', textDecoration: 'none', fontWeight: 600 }}>
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
