import React, { useState, useRef, useCallback, useEffect } from 'react';
import axios from 'axios';
import EmojiPicker from 'emoji-picker-react';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { useTheme } from '../context/ThemeContext';
import { useChat } from '../context/ChatContext';
import { showToast } from '../hooks/useToast';

// Components
import Toast from '../components/Toast';
import MessageBubble from '../components/chat/MessageBubble';
import ChatInput from '../components/chat/ChatInput';
import ChatSearch from '../components/chat/ChatSearch';
import ConversationItem from '../components/sidebar/ConversationItem';

// Modals
import CallOverlay from '../components/CallOverlay';
import ThemeModal from '../components/ThemeModal';
import ProfilePanel from '../components/ProfilePanel';
import AddContactModal from '../components/AddContactModal';
import CreateGroupModal from '../components/CreateGroupModal';
import PollModal from '../components/modals/PollModal';
import ScheduleModal from '../components/modals/ScheduleModal';
import ForwardModal from '../components/modals/ForwardModal';
import StarredModal from '../components/modals/StarredModal';
import MediaGalleryModal from '../components/modals/MediaGalleryModal';
import GifModal from '../components/modals/GifModal';
import PrivacyModal from '../components/modals/PrivacyModal';
import CallHistoryModal from '../components/modals/CallHistoryModal';
import InviteLinkModal from '../components/modals/InviteLinkModal';
import ContactSettingsModal, { getContactSettings, PRESET_THEMES } from '../components/modals/ContactSettingsModal';
import JoinGroupModal from '../components/modals/JoinGroupModal';

const API = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const formatDate = d => { const t = new Date(d), n = new Date(); const diff = Math.floor((n - t) / 86400000); if (diff === 0) return 'Today'; if (diff === 1) return 'Yesterday'; return t.toLocaleDateString(); };

const COLORS = ['#e11d48','#7c3aed','#0891b2','#059669','#d97706','#0e7490','#6d28d9','#be185d'];
const getColor = (id) => COLORS[parseInt((id || '0').slice(-2), 16) % COLORS.length];

const STATUS_BGS = ['#0a0f1e','#7c3aed','#059669','#e11d48','#d97706','#0891b2','#1e293b','#831843'];
const STATUS_EMOJIS = ['😊','❤️','🔥','✨','🎉','😂','🙏','💪','🎵','🌈'];

export default function Chat() {
  const { user, logout } = useAuth();
  const { socket, onlineUsers } = useSocket();
  const { colors, customBg } = useTheme();
  const {
    contacts, setContacts, groups, setGroups,
    activeChat, openChat, setActiveChat,
    messages, deleteMessage,
    archivedIds, pinnedIds, mutedIds,
    archiveChat, pinChat, muteChat,
    typingUsers, unreadCounts, loadContacts
  } = useChat();

  // UI state
  const [nav, setNav] = useState('chats');
  const [search, setSearch] = useState('');
  const [showChatSearch, setShowChatSearch] = useState(false);

  // Per-contact theme/settings
  const [contactThemeVersion, setContactThemeVersion] = useState(0);
  const getActiveChatColors = () => {
    if (!activeChat || activeChat.chatType === 'group') return { bubble: colors.bubble, chat: colors.chat, customBg };
    const settings = getContactSettings(activeChat._id);
    if (settings.theme === 'custom' && settings.customBg) return { bubble: colors.bubble, chat: null, customBg: settings.customBg };
    if (settings.theme && settings.theme !== 'default' && PRESET_THEMES[settings.theme]) {
      const t = PRESET_THEMES[settings.theme];
      return { bubble: t.bubble, chat: t.chat, customBg: null };
    }
    return { bubble: colors.bubble, chat: colors.chat, customBg };
  };
  const activeChatColors = getActiveChatColors();

  // Request notification permission once
  useEffect(() => {
    if (Notification && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);
  const [replyTo, setReplyTo] = useState(null);
  const [editingMsg, setEditingMsg] = useState(null);
  const [deleteDialog, setDeleteDialog] = useState(null);
  const [convCtx, setConvCtx] = useState(null);  // { item, type, x, y }
  const [callState, setCallState] = useState(null);
  const [localStream, setLocalStream] = useState(null);
  const [statuses, setStatuses] = useState([]);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [stText, setStText] = useState('');
  const [stEmoji, setStEmoji] = useState('😊');
  const [stBg, setStBg] = useState('#0a0f1e');
  const [stViewer, setStViewer] = useState(null);

  // Modal visibility
  const [modals, setModals] = useState({});
  const openModal = (name, data) => setModals(prev => ({ ...prev, [name]: data || true }));
  const closeModal = (name) => setModals(prev => { const n = { ...prev }; delete n[name]; return n; });

  const messagesEndRef = useRef(null);
  const peerRef = useRef(null);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const typingTimerRef = useRef({});

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages[activeChat?._id]]);

  // Call socket events
  useEffect(() => {
    if (!socket) return;
    socket.on('call:incoming', ({ from, callType, offer }) => {
      const peer = contacts.find(c => c._id === from) || { _id: from, name: from };
      setCallState({ type: callType, peer, status: 'incoming', offer, from });
    });
    socket.on('call:answered', async ({ answer }) => {
      if (peerRef.current) await peerRef.current.setRemoteDescription(new RTCSessionDescription(answer));
      setCallState(p => p ? { ...p, status: 'active' } : p);
    });
    socket.on('call:ice-candidate', async ({ candidate }) => {
      try { if (peerRef.current) await peerRef.current.addIceCandidate(new RTCIceCandidate(candidate)); } catch {}
    });
    socket.on('call:ended', endCall);
    socket.on('call:rejected', () => { endCall(); showToast('📵 Call declined'); });
    socket.on('call:screen-share', ({ enabled }) => showToast(enabled ? '📺 Screen sharing' : '📺 Screen sharing ended'));
    return () => { ['call:incoming','call:answered','call:ice-candidate','call:ended','call:rejected','call:screen-share'].forEach(e => socket.off(e)); };
  }, [socket, contacts]);

  // Calls
  const createPC = (peerId, callType) => {
    const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
    pc.onicecandidate = e => { if (e.candidate) socket?.emit('call:ice-candidate', { to: peerId, candidate: e.candidate }); };
    pc.ontrack = e => { if (remoteVideoRef.current) remoteVideoRef.current.srcObject = e.streams[0]; };
    return pc;
  };

  const initiateCall = useCallback(async (callType, peer = null) => {
    const p = peer || activeChat;
    if (!p) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: callType === 'video', audio: true });
      setLocalStream(stream);
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
      const pc = createPC(p._id, callType);
      peerRef.current = pc;
      stream.getTracks().forEach(t => pc.addTrack(t, stream));
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket?.emit('call:initiate', { to: p._id, callType, offer });
      socket?.emit('call:log', { peer: p._id, callType, direction: 'outgoing' });
      setCallState({ type: callType, peer: p, status: 'calling' });
    } catch { showToast('❌ Camera/mic access denied', 'error'); }
  }, [activeChat, socket]);

  const answerCall = useCallback(async () => {
    if (!callState) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: callState.type === 'video', audio: true });
      setLocalStream(stream);
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
      const pc = createPC(callState.from, callState.type);
      peerRef.current = pc;
      stream.getTracks().forEach(t => pc.addTrack(t, stream));
      await pc.setRemoteDescription(new RTCSessionDescription(callState.offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socket?.emit('call:answer', { to: callState.from, answer });
      socket?.emit('call:log', { peer: callState.from, callType: callState.type, direction: 'incoming' });
      setCallState(p => ({ ...p, status: 'active' }));
    } catch { showToast('❌ Could not answer', 'error'); }
  }, [callState, socket]);

  const endCall = useCallback(() => {
    if (callState) socket?.emit('call:end', { to: callState.peer?._id || callState.from });
    peerRef.current?.close(); peerRef.current = null;
    localStream?.getTracks().forEach(t => t.stop());
    setLocalStream(null); setCallState(null);
  }, [callState, socket, localStream]);

  const shareScreen = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      socket?.emit('call:screen-share', { to: callState?.peer?._id, enabled: true });
      showToast('📺 Screen sharing started');
      stream.getVideoTracks()[0].onended = () => { socket?.emit('call:screen-share', { to: callState?.peer?._id, enabled: false }); showToast('📺 Sharing stopped'); };
    } catch { showToast('❌ Cannot share screen', 'error'); }
  };

  // Status
  const postStatus = () => {
    const s = { id: 's' + Date.now(), userId: 'me', text: stText, emoji: stEmoji, bg: stBg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), viewedBy: [] };
    setStatuses(prev => [s, ...prev.filter(x => x.userId !== 'me')]);
    setStText(''); setShowStatusModal(false); showToast('✅ Status posted!');
  };

  // Filtered lists
  const sortedContacts = [...contacts]
    .filter(c => !archivedIds.includes(c._id) && c.name?.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => (pinnedIds.includes(b._id) ? 1 : 0) - (pinnedIds.includes(a._id) ? 1 : 0));
  const sortedGroups = [...groups]
    .filter(g => !archivedIds.includes(g._id) && g.name?.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => (pinnedIds.includes(b._id) ? 1 : 0) - (pinnedIds.includes(a._id) ? 1 : 0));
  const archivedItems = [...contacts, ...groups].filter(i => archivedIds.includes(i._id));

  // Messages for active chat
  const chatMsgs = (messages[activeChat?._id] || []).filter(m => !m.deletedForMe);
  const isTyping = activeChat?.chatType === 'user' && typingUsers[activeChat._id];
  const totalUnread = Object.values(unreadCounts).reduce((s, v) => s + v, 0);

  const groupedMsgs = chatMsgs.reduce((acc, msg) => {
    const k = formatDate(msg.createdAt);
    if (!acc[k]) acc[k] = [];
    acc[k].push(msg);
    return acc;
  }, {});

  // Conv context menu
  const showConvMenu = (e, item, type) => {
    e.preventDefault();
    setConvCtx({ item, type, x: Math.min(e.clientX, window.innerWidth - 200), y: Math.min(e.clientY, window.innerHeight - 320) });
  };

  const lastSeen = (c) => {
    if (!c.lastSeen) return c.phone || '';
    try {
      const d = new Date(c.lastSeen), now = new Date();
      const diff = Math.floor((now - d) / 60000);
      if (diff < 1) return 'Last seen just now';
      if (diff < 60) return `Last seen ${diff}m ago`;
      if (diff < 1440) return `Last seen today at ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
      return `Last seen ${d.toLocaleDateString()}`;
    } catch { return ''; }
  };

  return (
    <div className="app-container" onClick={() => setConvCtx(null)}>
      <Toast />

      {/* ── LEFT NAV ── */}
      <div className="left-nav">
        <div className="nav-logo">N</div>
        {[
          { id: 'chats', icon: '💬', label: 'Chats', badge: totalUnread },
          { id: 'groups', icon: '👥', label: 'Groups' },
          { id: 'status', icon: '🔵', label: 'Status' },
          { id: 'archive', icon: '🗂️', label: 'Archive', badge: archivedItems.length },
        ].map(({ id, icon, label, badge }) => (
          <button key={id} className={`nav-btn ${nav === id ? 'active' : ''}`} onClick={() => { setNav(id); setActiveChat(null); }} title={label}>
            {icon}
            {badge > 0 && <span className="nav-badge">{badge > 99 ? '99+' : badge}</span>}
          </button>
        ))}
        <div style={{ flex: 1 }} />
        <button className="nav-btn" onClick={() => openModal('starred')} title="Starred Messages">⭐</button>
        <button className="nav-btn" onClick={() => openModal('callHistory')} title="Call History">📞</button>
        <button className="nav-btn" onClick={() => openModal('privacy')} title="Privacy & Security">🔒</button>
        <button className="nav-btn" onClick={() => openModal('joinGroup')} title="Join Group">🔗</button>
        <button className="nav-btn" onClick={() => openModal('theme')} title="Theme">🎨</button>
        <button className="nav-btn" onClick={() => openModal('profile')} title="Profile">👤</button>
        <button className="nav-btn" onClick={logout} title="Logout" style={{ color: 'rgba(255,255,255,0.3)' }}>🚪</button>
      </div>

      {/* ── SIDEBAR ── */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="sidebar-title">
            {nav === 'chats' ? 'Chats' : nav === 'groups' ? 'Groups' : nav === 'status' ? 'Status' : 'Archived'}
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            {nav === 'chats' && <button className="icon-btn" onClick={() => openModal('addContact')} title="Add Contact">➕</button>}
            {nav === 'groups' && (
              <>
                <button className="icon-btn" onClick={() => openModal('createGroup')} title="New Group">👥</button>
                <button className="icon-btn" onClick={() => openModal('joinGroup')} title="Join Group">🔗</button>
              </>
            )}
            {nav === 'status' && <button className="icon-btn" onClick={() => setShowStatusModal(true)} title="Post Status">➕</button>}
          </div>
        </div>

        {nav !== 'status' && (
          <div className="search-wrap">
            <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 14 }}>🔍</span>
            <input className="search-input" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} />
            {search && <button onClick={() => setSearch('')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.3)', cursor: 'pointer' }}>✕</button>}
          </div>
        )}

        <div className="conv-list">
          {/* STATUS TAB */}
          {nav === 'status' && (
            <div>
              <div className="section-label">My Status</div>
              {(() => { const myS = statuses.find(s => s.userId === 'me'); return (
                <div className="status-row" onClick={() => myS ? setStViewer(myS) : setShowStatusModal(true)}>
                  <div style={{ position: 'relative' }}>
                    <div className="conv-avatar placeholder" style={{ background: myS ? '#00b4d8' : 'rgba(255,255,255,0.1)', fontSize: 18 }}>{myS ? myS.emoji : '➕'}</div>
                    {myS && <div className="status-ring" />}
                  </div>
                  <div><div style={{ fontWeight: 600 }}>My Status</div><div style={{ fontSize: 12, opacity: 0.5 }}>{myS ? `Today at ${myS.time}` : 'Tap to add status'}</div></div>
                </div>
              ); })()}
              <button className="btn-secondary" style={{ margin: '8px 12px', width: 'calc(100% - 24px)' }} onClick={() => setShowStatusModal(true)}>➕ Add / Update Status</button>
              <div className="section-label" style={{ marginTop: 12 }}>Recent Updates</div>
              {statuses.filter(s => s.userId !== 'me').map(s => {
                const c = contacts.find(x => x._id === s.userId);
                if (!c) return null;
                return (
                  <div key={s.id} className="status-row" onClick={() => setStViewer(s)}>
                    <div style={{ position: 'relative' }}>
                      <div className="conv-avatar placeholder" style={{ background: getColor(c._id) }}>{c.name[0]?.toUpperCase()}</div>
                      <div className={`status-ring ${s.viewedBy?.includes('me') ? 'viewed' : ''}`} />
                    </div>
                    <div><div style={{ fontWeight: 600 }}>{c.name}</div><div style={{ fontSize: 12, opacity: 0.5 }}>{s.time}</div></div>
                  </div>
                );
              })}
            </div>
          )}

          {/* CHATS TAB */}
          {nav === 'chats' && sortedContacts.map(c => (
            <ConversationItem key={c._id} item={c} type="user" isActive={activeChat?._id === c._id} onOpen={() => openChat(c, 'user')} onContextMenu={e => showConvMenu(e, c, 'user')} />
          ))}
          {nav === 'chats' && sortedContacts.length === 0 && !search && (
            <div className="empty-list"><div style={{ fontSize: 40 }}>💬</div><div>No chats yet</div><button className="btn-primary" style={{ width: 'auto', padding: '10px 20px', marginTop: 12, fontSize: 13 }} onClick={() => openModal('addContact')}>➕ Add Contact</button></div>
          )}

          {/* GROUPS TAB */}
          {nav === 'groups' && sortedGroups.map(g => (
            <ConversationItem key={g._id} item={g} type="group" isActive={activeChat?._id === g._id} onOpen={() => openChat(g, 'group')} onContextMenu={e => showConvMenu(e, g, 'group')} />
          ))}
          {nav === 'groups' && sortedGroups.length === 0 && !search && (
            <div className="empty-list"><div style={{ fontSize: 40 }}>👥</div><div>No groups yet</div><button className="btn-primary" style={{ width: 'auto', padding: '10px 20px', marginTop: 12, fontSize: 13 }} onClick={() => openModal('createGroup')}>👥 Create Group</button></div>
          )}

          {/* ARCHIVE TAB */}
          {nav === 'archive' && archivedItems.map(item => {
            const isGrp = groups.some(g => g._id === item._id);
            return <ConversationItem key={item._id} item={item} type={isGrp ? 'group' : 'user'} isActive={activeChat?._id === item._id} onOpen={() => openChat(item, isGrp ? 'group' : 'user')} onContextMenu={e => showConvMenu(e, item, isGrp ? 'group' : 'user')} />;
          })}
          {nav === 'archive' && archivedItems.length === 0 && <div className="empty-list"><div style={{ fontSize: 40 }}>🗂️</div><div>No archived chats</div></div>}
        </div>
      </div>

      {/* ── CHAT AREA ── */}
      {activeChat ? (
        <div className="chat-area">
          <div className="chat-bg" style={activeChatColors.customBg ? { backgroundImage: `url(${activeChatColors.customBg})`, backgroundSize: 'cover', filter: 'brightness(.4)' } : { background: activeChatColors.chat || colors.chat }} />

          {/* Chat Header */}
          <div className="chat-header" style={{ background: `${colors.sidebar}f0` }}>
            <div style={{ position: 'relative', flexShrink: 0 }}>
              {activeChat.avatar
                ? <img src={activeChat.avatar} alt="" className="conv-avatar" style={{ width: 44, height: 44 }} />
                : <div className="conv-avatar placeholder" style={{ width: 44, height: 44, fontSize: 16, background: getColor(activeChat._id) }}>{activeChat.name?.[0]?.toUpperCase()}</div>
              }
              {activeChat.chatType === 'user' && onlineUsers.has(activeChat._id) && <div className="online-dot" />}
            </div>
            <div style={{ flex: 1 }}>
              <div className="ch-name">{activeChat.name}</div>
              <div className="ch-status">
                {activeChat.chatType === 'group'
                  ? `${activeChat.members?.length || 0} members`
                  : onlineUsers.has(activeChat._id)
                    ? <span style={{ color: '#22c55e' }}>Online</span>
                    : lastSeen(activeChat)
                }
              </div>
            </div>
            <div className="ch-actions">
              <button className="icon-btn" onClick={() => setShowChatSearch(v => !v)} title="Search">🔍</button>
              {activeChat.chatType !== 'group' && (
                <>
                  <button className="icon-btn" onClick={() => initiateCall('audio')} title="Call">📞</button>
                  <button className="icon-btn" onClick={() => initiateCall('video')} title="Video">📹</button>
                  <button className="icon-btn" onClick={() => openModal('contactSettings', activeChat)} title="Chat Settings">🎨</button>
                </>
              )}
              <button className="icon-btn" onClick={e => { e.stopPropagation(); showConvMenu(e, activeChat, activeChat.chatType); }} title="More">⋮</button>
            </div>
          </div>

          {/* Chat Search Bar */}
          {showChatSearch && <ChatSearch onClose={() => setShowChatSearch(false)} />}

          {/* Messages */}
          <div className="messages-area" onClick={() => setConvCtx(null)}>
            {Object.entries(groupedMsgs).map(([date, msgs]) => (
              <React.Fragment key={date}>
                <div className="date-sep">{date}</div>
                {msgs.map(msg => (
                  <MessageBubble
                    key={msg._id}
                    msg={msg}
                    colors={{ ...colors, bubble: activeChatColors.bubble }}
                    onReply={setReplyTo}
                    onEdit={setEditingMsg}
                    onDelete={(m, isSent) => setDeleteDialog({ messageId: m._id, isSent })}
                    onForward={m => openModal('forward', m)}
                  />
                ))}
              </React.Fragment>
            ))}
            {isTyping && (
              <div className="message-row received">
                <div className="conv-avatar placeholder" style={{ width: 28, height: 28, fontSize: 11, background: getColor(activeChat._id) }}>{activeChat.name?.[0]?.toUpperCase()}</div>
                <div className="message-bubble received"><div className="typing-dots"><span /><span /><span /></div></div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Chat Input */}
          <ChatInput
            activeChat={activeChat}
            replyTo={replyTo}
            onClearReply={() => setReplyTo(null)}
            editingMsg={editingMsg}
            onClearEdit={() => setEditingMsg(null)}
            colors={colors}
            onOpenPoll={() => openModal('poll')}
            onOpenSchedule={() => openModal('schedule')}
            onOpenGif={() => openModal('gif')}
          />
        </div>
      ) : (
        <div className="no-chat" style={{ background: colors.chat }}>
          <div className="welcome-box">
            <div className="welcome-logo">NexChat</div>
            <div style={{ fontSize: 56, margin: '12px 0' }}>💬</div>
            <div style={{ fontSize: 20, fontWeight: 700 }}>Welcome, {user?.name?.split(' ')[0]}</div>
            <div style={{ fontSize: 14, opacity: 0.4, textAlign: 'center', maxWidth: 260, lineHeight: 1.6 }}>Select a conversation or add a contact to get started</div>
            <button className="btn-primary" style={{ width: 'auto', padding: '12px 24px', marginTop: 16 }} onClick={() => openModal('addContact')}>➕ Add Contact</button>
          </div>
        </div>
      )}

      {/* ── CONTEXT MENU ── */}
      {convCtx && (
        <div className="ctx-menu" style={{ top: convCtx.y, left: convCtx.x }} onClick={() => setConvCtx(null)}>
          <div className="ctx-item" onClick={() => archiveChat(convCtx.item._id)}>{archivedIds.includes(convCtx.item._id) ? '📤 Unarchive' : '🗂️ Archive'}</div>
          <div className="ctx-item" onClick={() => pinChat(convCtx.item._id)}>{pinnedIds.includes(convCtx.item._id) ? '📌 Unpin' : '📌 Pin'}</div>
          <div className="ctx-item" onClick={() => muteChat(convCtx.item._id)}>{mutedIds.includes(convCtx.item._id) ? '🔔 Unmute' : '🔕 Mute'}</div>
          {convCtx.type === 'user' && <div className="ctx-item" onClick={() => { openModal('contactSettings', convCtx.item); setConvCtx(null); }}>🎨 Chat Settings</div>}
          {convCtx.item._id === activeChat?._id && <div className="ctx-item" onClick={() => openModal('gallery')}>📁 Media & Files</div>}
          {convCtx.item._id === activeChat?._id && <div className="ctx-item" onClick={() => openModal('schedule')}>⏰ Schedule Message</div>}
          {convCtx.type === 'group' && convCtx.item._id === activeChat?._id && <div className="ctx-item" onClick={() => openModal('inviteLink', convCtx.item)}>🔗 Invite Link</div>}
          <div className="ctx-divider" />
          {convCtx.type === 'user' && <div className="ctx-item danger" onClick={async () => { try { await axios.post(`${API}/users/block`, { userId: convCtx.item._id }); setContacts(prev => prev.filter(c => c._id !== convCtx.item._id)); if (activeChat?._id === convCtx.item._id) setActiveChat(null); showToast('🚫 Blocked'); } catch {} }}>🚫 Block</div>}
        </div>
      )}

      {/* ── DELETE DIALOG ── */}
      {deleteDialog && (
        <div className="modal-overlay" onClick={() => setDeleteDialog(null)}>
          <div className="modal-box" style={{ maxWidth: 340 }} onClick={e => e.stopPropagation()}>
            <div className="modal-title">🗑️ Delete Message?</div>
            <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 13, marginBottom: 18 }}>Choose who to delete this message for</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <button className="btn-secondary" onClick={() => { deleteMessage(deleteDialog.messageId, 'me'); setDeleteDialog(null); }}>🙋 Delete for Me</button>
              {deleteDialog.isSent && <button className="btn-danger" onClick={() => { deleteMessage(deleteDialog.messageId, 'everyone'); setDeleteDialog(null); }}>🌐 Delete for Everyone</button>}
              <button className="btn-secondary" onClick={() => setDeleteDialog(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* ── STATUS MODALS ── */}
      {showStatusModal && (
        <div className="modal-overlay" onClick={() => setShowStatusModal(false)}>
          <div className="modal-box" onClick={e => e.stopPropagation()}>
            <div className="modal-title">🔵 Post Status <button className="modal-close" onClick={() => setShowStatusModal(false)}>✕</button></div>
            <label className="form-label">Message</label>
            <input className="form-input" placeholder="What's on your mind?" value={stText} onChange={e => setStText(e.target.value)} maxLength={120} />
            <label className="form-label" style={{ marginTop: 12 }}>Emoji</label>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
              {STATUS_EMOJIS.map(e => <span key={e} style={{ fontSize: 24, cursor: 'pointer', padding: 4, borderRadius: 8, background: stEmoji === e ? 'rgba(0,180,216,.15)' : 'transparent', border: stEmoji === e ? '1px solid #00b4d8' : '1px solid transparent' }} onClick={() => setStEmoji(e)}>{e}</span>)}
            </div>
            <label className="form-label">Background</label>
            <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
              {STATUS_BGS.map(c => <div key={c} style={{ width: 28, height: 28, borderRadius: '50%', background: c, cursor: 'pointer', border: stBg === c ? '2px solid #00b4d8' : '2px solid transparent' }} onClick={() => setStBg(c)} />)}
            </div>
            <button className="btn-primary" onClick={postStatus}>📤 Post Status</button>
          </div>
        </div>
      )}

      {stViewer && (
        <div className="modal-overlay" style={{ background: 'rgba(0,0,0,0.85)' }} onClick={() => setStViewer(null)}>
          <div style={{ background: stViewer.bg || '#111827', borderRadius: 20, padding: '40px 32px', textAlign: 'center', maxWidth: 340, width: '90%', position: 'relative' }} onClick={e => e.stopPropagation()}>
            <button className="modal-close" style={{ position: 'absolute', top: 12, right: 12 }} onClick={() => setStViewer(null)}>✕</button>
            <div style={{ fontSize: 64 }}>{stViewer.emoji}</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: '#fff', marginTop: 12 }}>{stViewer.text}</div>
            <div style={{ fontSize: 12, opacity: 0.4, marginTop: 12 }}>Today at {stViewer.time}</div>
          </div>
        </div>
      )}

      {/* ── CALL OVERLAY ── */}
      {callState && (
        <CallOverlay
          callState={callState}
          localVideoRef={localVideoRef}
          remoteVideoRef={remoteVideoRef}
          onAnswer={answerCall}
          onEnd={endCall}
          onShareScreen={shareScreen}
          onReject={() => { socket?.emit('call:reject', { to: callState.from || callState.peer._id }); setCallState(null); }}
        />
      )}

      {/* ── ALL MODALS ── */}
      {modals.theme && <ThemeModal onClose={() => closeModal('theme')} />}
      {modals.profile && <ProfilePanel onClose={() => closeModal('profile')} />}
      {modals.addContact && <AddContactModal onClose={() => closeModal('addContact')} onAdded={c => { setContacts(prev => prev.find(x => x._id === c._id) ? prev : [...prev, c]); }} />}
      {modals.createGroup && <CreateGroupModal contacts={contacts} onClose={() => closeModal('createGroup')} onCreated={g => { setGroups(prev => [...prev, g]); closeModal('createGroup'); }} />}
      {modals.poll && activeChat && <PollModal onClose={() => closeModal('poll')} />}
      {modals.schedule && activeChat && <ScheduleModal onClose={() => closeModal('schedule')} />}
      {modals.forward && <ForwardModal msg={modals.forward} onClose={() => closeModal('forward')} />}
      {modals.starred && <StarredModal onClose={() => closeModal('starred')} />}
      {modals.gallery && activeChat && <MediaGalleryModal onClose={() => closeModal('gallery')} />}
      {modals.gif && activeChat && <GifModal onClose={() => closeModal('gif')} />}
      {modals.privacy && <PrivacyModal onClose={() => closeModal('privacy')} />}
      {modals.callHistory && <CallHistoryModal onClose={() => closeModal('callHistory')} onCall={(peer, type) => initiateCall(type, peer)} />}
      {modals.inviteLink && <InviteLinkModal group={modals.inviteLink} onClose={() => closeModal('inviteLink')} />}
      {modals.joinGroup && <JoinGroupModal onClose={() => closeModal('joinGroup')} />}
      {modals.contactSettings && <ContactSettingsModal contact={modals.contactSettings} onClose={() => { closeModal('contactSettings'); setContactThemeVersion(v => v + 1); }} />}
    </div>
  );
}
