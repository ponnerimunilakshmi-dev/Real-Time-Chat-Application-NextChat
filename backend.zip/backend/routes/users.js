const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const User    = require('../models/User');
const bcrypt  = require('bcryptjs');
const multer  = require('multer');
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

const storage = multer.memoryStorage();
const upload  = multer({ storage, limits:{ fileSize:50*1024*1024 } });

// ── GET /api/users/me ─────────────────────────────────
router.get('/me', auth, (req, res) => res.json(req.user));

// ── GET /api/users/search?phone=|username= ───────────
router.get('/search', auth, async (req, res) => {
  try {
    const { phone, username } = req.query;
    const filter = phone ? { phone } : username ? { username: username.toLowerCase() } : null;
    if (!filter) return res.status(400).json({ message:'phone or username required' });
    const user = await User.findOne(filter).select('name phone username avatar about isOnline lastSeen privacy');
    if (!user) return res.status(404).json({ message:'User not found on NexChat' });
    res.json(user);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/users/profile ───────────────────────────
router.put('/profile', auth, async (req, res) => {
  try {
    const { name, about, username } = req.body;
    const updates = {};
    if (name) updates.name = name;
    if (about !== undefined) updates.about = about;
    if (username) {
      // Check unique
      const existing = await User.findOne({ username: username.toLowerCase(), _id: { $ne: req.user._id } });
      if (existing) return res.status(400).json({ message:'Username already taken' });
      updates.username = username.toLowerCase();
    }
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new:true }).select('-password -otp');
    res.json(user);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/avatar ───────────────────────────
router.post('/avatar', auth, upload.single('avatar'), async (req, res) => {
  try {
    let avatarUrl = '';
    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_CLOUD_NAME !== 'your_cloud_name') {
      const result = await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream({ folder:'nexchat/avatars', resource_type:'image' }, (err, r) => err ? reject(err) : resolve(r));
        stream.end(req.file.buffer);
      });
      avatarUrl = result.secure_url;
    } else {
      avatarUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    }
    const user = await User.findByIdAndUpdate(req.user._id, { avatar: avatarUrl }, { new:true }).select('-password -otp');
    res.json({ avatar: avatarUrl, user });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/users/theme ─────────────────────────────
router.put('/theme', auth, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(req.user._id, { theme: req.body.theme }, { new:true }).select('-password -otp');
    res.json(user);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/users/privacy ───────────────────────────
router.put('/privacy', auth, async (req, res) => {
  try {
    const { lastSeen, readReceipts, onlineStatus, profilePhoto, about } = req.body;
    const updates = {};
    if (lastSeen)     updates['privacy.lastSeen']     = lastSeen;
    if (readReceipts !== undefined) updates['privacy.readReceipts'] = readReceipts;
    if (onlineStatus) updates['privacy.onlineStatus'] = onlineStatus;
    if (profilePhoto) updates['privacy.profilePhoto'] = profilePhoto;
    if (about)        updates['privacy.about']        = about;
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new:true }).select('-password -otp');
    res.json(user);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/users/disappearing ──────────────────────
router.put('/disappearing', auth, async (req, res) => {
  try {
    const { seconds } = req.body; // 0 = off
    const user = await User.findByIdAndUpdate(req.user._id, { disappearingMessages: seconds || 0 }, { new:true }).select('-password -otp');
    res.json(user);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/2fa/enable ───────────────────────
router.post('/2fa/enable', auth, async (req, res) => {
  try {
    const { pin } = req.body;
    if (!pin || pin.length !== 6) return res.status(400).json({ message:'PIN must be 6 digits' });
    const hashed = await bcrypt.hash(pin, 10);
    await User.findByIdAndUpdate(req.user._id, { 'twoFA.enabled':true, 'twoFA.pin':hashed });
    res.json({ message:'2FA enabled' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/2fa/verify ───────────────────────
router.post('/2fa/verify', auth, async (req, res) => {
  try {
    const { pin } = req.body;
    const user = await User.findById(req.user._id);
    if (!user.twoFA?.enabled) return res.json({ verified: true });
    const ok = await bcrypt.compare(pin, user.twoFA.pin);
    res.json({ verified: ok });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/2fa/disable ──────────────────────
router.post('/2fa/disable', auth, async (req, res) => {
  try {
    const { pin } = req.body;
    const user = await User.findById(req.user._id);
    const ok = await bcrypt.compare(pin, user.twoFA?.pin || '');
    if (!ok) return res.status(400).json({ message:'Wrong PIN' });
    await User.findByIdAndUpdate(req.user._id, { 'twoFA.enabled':false, 'twoFA.pin':'' });
    res.json({ message:'2FA disabled' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/users/calls ─────────────────────────────
router.get('/calls', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('callLog.peer','name avatar phone')
      .select('callLog');
    res.json(user.callLog.reverse());
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/calls/log ────────────────────────
router.post('/calls/log', auth, async (req, res) => {
  try {
    const { peer, callType, direction, duration } = req.body;
    await User.findByIdAndUpdate(req.user._id, {
      $push: { callLog: { peer, callType, direction, duration, startedAt: new Date() } }
    });
    res.json({ message:'Logged' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/users/contacts ──────────────────────────
router.get('/contacts', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('contacts','-password -otp');
    res.json(user.contacts);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/contacts ─────────────────────────
router.post('/contacts', auth, async (req, res) => {
  try {
    const { phone, userId } = req.body;
    const contact = userId
      ? await User.findById(userId).select('-password -otp')
      : await User.findOne({ phone }).select('-password -otp');
    if (!contact) return res.status(404).json({ message:'User not found' });
    if (contact._id.equals(req.user._id)) return res.status(400).json({ message:'Cannot add yourself' });
    const me = await User.findById(req.user._id);
    if (me.contacts.some(c => c.equals(contact._id))) return res.status(400).json({ message:'Already in contacts' });
    me.contacts.push(contact._id);
    await me.save();
    res.json({ message:'Contact added', contact });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/users/block ────────────────────────────
router.post('/block', auth, async (req, res) => {
  try {
    const targetId = req.body.userId || req.params.userId;
    if (!targetId) return res.status(400).json({ message:'userId required' });
    const me = await User.findById(req.user._id);
    if (!me.blockedUsers.some(id => id.equals(targetId))) me.blockedUsers.push(targetId);
    me.contacts = me.contacts.filter(id => !id.equals(targetId));
    await me.save();
    res.json({ message:'Blocked' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});
router.post('/block/:userId', auth, async (req, res) => {
  req.body.userId = req.params.userId; return router.handle(req, res, ()=>{});
});

// ── POST /api/users/unblock/:userId ─────────────────
router.post('/unblock/:userId', auth, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user._id, { $pull:{ blockedUsers: req.params.userId } });
    res.json({ message:'Unblocked' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
