const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const User = require('../models/User');

// Generate 6-digit OTP
const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

// Send OTP via Fast2SMS
const sendOTP = async (phone, otp) => {
  const apiKey = process.env.FAST2SMS_API_KEY;

  // If no API key set, just log OTP to console (dev mode)
  if (!apiKey || apiKey === 'your_fast2sms_api_key_here') {
    console.log('\n========================================');
    console.log(`📱 OTP for ${phone}: ${otp}`);
    console.log('========================================\n');
    return { status: true, message: 'dev mode - check console' };
  }

  try {
    // Method 1: GET request with query params (most reliable)
    const response = await axios.get('https://www.fast2sms.com/dev/bulkV2', {
      params: {
        authorization: apiKey,
        variables_values: otp,
        route: 'otp',
        numbers: phone
      }
    });
    console.log('Fast2SMS response:', response.data);
    return response.data;
  } catch (err1) {
    console.log('Method 1 failed, trying Method 2...');
    try {
      // Method 2: POST with form data
      const params = new URLSearchParams();
      params.append('variables_values', otp);
      params.append('route', 'otp');
      params.append('numbers', phone);

      const response = await axios.post(
        'https://www.fast2sms.com/dev/bulkV2',
        params.toString(),
        {
          headers: {
            authorization: apiKey,
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
      console.log('Fast2SMS response:', response.data);
      return response.data;
    } catch (err2) {
      console.error('Fast2SMS Error Details:', {
        status: err2.response?.status,
        data: err2.response?.data,
        message: err2.message
      });
      // Still log OTP to console as fallback so you can test
      console.log('\n========================================');
      console.log(`📱 OTP for ${phone}: ${otp}  (SMS failed - use this)`);
      console.log('========================================\n');
      throw new Error(
        err2.response?.data?.message ||
        `SMS failed: ${err2.response?.data || err2.message}`
      );
    }
  }
};

// POST /api/auth/send-otp
router.post('/send-otp', async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone || phone.length < 10) {
      return res.status(400).json({ message: 'Valid phone number required' });
    }

    const otp = generateOTP();
    const otpExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Check if user exists
    let user = await User.findOne({ phone });
    if (user) {
      user.otp = otp;
      user.otpExpiry = otpExpiry;
      await user.save();
    } else {
      // Temporarily store OTP for new user registration
      // We'll use a temp collection or cache; here store in a temp user doc
      user = new User({
        name: 'Temp',
        phone,
        password: 'temp',
        otp,
        otpExpiry,
        isVerified: false
      });
      await user.save();
    }

    const isDevMode = !process.env.FAST2SMS_API_KEY || process.env.FAST2SMS_API_KEY === 'your_fast2sms_api_key_here';
    try {
      await sendOTP(phone, otp);
      res.json({
        message: isDevMode ? 'DEV MODE: Check backend terminal for OTP' : 'OTP sent to your mobile!',
        phone,
        ...(isDevMode && { devOtp: otp })
      });
    } catch (smsErr) {
      // SMS failed but OTP saved - still let user proceed
      res.json({
        message: 'SMS unavailable. Your OTP: ' + otp,
        phone,
        devOtp: otp,
        smsError: smsErr.message
      });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST /api/auth/verify-otp (for registration verification)
router.post('/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;
    const user = await User.findOne({ phone });

    if (!user || user.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
    if (new Date() > user.otpExpiry) {
      return res.status(400).json({ message: 'OTP expired' });
    }

    user.isVerified = true;
    user.otp = undefined;
    user.otpExpiry = undefined;
    await user.save();

    res.json({ message: 'OTP verified successfully', verified: true });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, phone, password } = req.body;

    const existingUser = await User.findOne({ phone });
    if (!existingUser || !existingUser.isVerified) {
      return res.status(400).json({ message: 'Phone not verified. Please verify OTP first.' });
    }
    if (existingUser.password !== 'temp') {
      return res.status(400).json({ message: 'User already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    existingUser.name = name;
    existingUser.password = hashedPassword;
    await existingUser.save();

    const token = jwt.sign({ userId: existingUser._id }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      token,
      user: {
        _id: existingUser._id,
        name: existingUser.name,
        phone: existingUser.phone,
        avatar: existingUser.avatar,
        about: existingUser.about,
        theme: existingUser.theme
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;
    const user = await User.findOne({ phone });

    if (!user || !user.isVerified) {
      return res.status(400).json({ message: 'User not found or not verified' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({
      token,
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        avatar: user.avatar,
        about: user.about,
        theme: user.theme,
        contacts: user.contacts
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// POST /api/auth/login-otp (Login with OTP)
router.post('/login-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;
    const user = await User.findOne({ phone });

    if (!user || user.password === 'temp') {
      return res.status(400).json({ message: 'User not found' });
    }
    if (user.otp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }
    if (new Date() > user.otpExpiry) {
      return res.status(400).json({ message: 'OTP expired' });
    }

    user.otp = undefined;
    user.otpExpiry = undefined;
    await user.save();

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });

    res.json({
      token,
      user: {
        _id: user._id,
        name: user.name,
        phone: user.phone,
        avatar: user.avatar,
        about: user.about,
        theme: user.theme,
        contacts: user.contacts
      }
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
