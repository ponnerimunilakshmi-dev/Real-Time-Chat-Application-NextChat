const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');
const Message = require('../models/Message');
const User    = require('../models/User');
const multer  = require('multer');
const cloudinary = require('cloudinary').v2;
const axios   = require('axios');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

const storage = multer.memoryStorage();
const upload  = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } });

const populate = q => q.populate('sender','name avatar').populate('replyTo').populate('forwardedFrom');

// ── helpers ──────────────────────────────────────────
async function fetchLinkPreview(url) {
  try {
    const domain = new URL(url).hostname.replace('www.','');
    // Use Open Graph meta scraper approach
    const res = await axios.get(url, { timeout: 4000, headers:{ 'User-Agent':'NexChatBot/1.0' } });
    const html = res.data;
    const getM = (prop) => {
      const m = html.match(new RegExp(`<meta[^>]*(?:property|name)=["']${prop}["'][^>]*content=["']([^"']+)["']`, 'i'))
               || html.match(new RegExp(`<meta[^>]*content=["']([^"']+)["'][^>]*(?:property|name)=["']${prop}["']`, 'i'));
      return m ? m[1] : '';
    };
    const title = getM('og:title') || html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1] || '';
    const description = getM('og:description') || getM('description') || '';
    const image = getM('og:image') || '';
    return { url, title: title.slice(0,120), description: description.slice(0,200), image, domain };
  } catch { return null; }
}

function detectLinks(text) {
  const m = text.match(/https?:\/\/[^\s]+/);
  return m ? m[0] : null;
}

// ── GET /api/messages/starred ────────────────────────
router.get('/starred', auth, async (req, res) => {
  try {
    const msgs = await populate(Message.find({ starredBy: req.user._id, deletedFor: { $ne: req.user._id } })).sort({ createdAt: -1 }).limit(200);
    res.json(msgs);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/messages/scheduled ─────────────────────
router.get('/scheduled', auth, async (req, res) => {
  try {
    const msgs = await Message.find({ sender: req.user._id, isSent: false }).sort({ scheduledAt: 1 });
    res.json(msgs);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── DELETE /api/messages/clear/:chatId ──────────────
router.delete('/clear/:chatId', auth, async (req, res) => {
  try {
    await Message.updateMany(
      { $or:[{ sender:req.user._id, receiver:req.params.chatId },{ sender:req.params.chatId, receiver:req.user._id },{ group:req.params.chatId }] },
      { $addToSet:{ deletedFor:req.user._id } }
    );
    res.json({ message:'Chat cleared' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/messages/search ─────────────────────────
router.get('/search', auth, async (req, res) => {
  try {
    const { chatId, q, chatType } = req.query;
    if (!q) return res.json([]);
    const chatFilter = chatType === 'group'
      ? { group: chatId }
      : { $or:[{ sender:req.user._id, receiver:chatId },{ sender:chatId, receiver:req.user._id }] };
    const msgs = await populate(Message.find({
      ...chatFilter,
      content: { $regex: q, $options:'i' },
      deletedFor: { $ne: req.user._id },
      deletedForEveryone: false
    })).sort({ createdAt: -1 }).limit(50);
    res.json(msgs);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/messages/media/:chatId ─────────────────
router.get('/media/:chatId', auth, async (req, res) => {
  try {
    const { chatType } = req.query;
    const chatFilter = chatType === 'group'
      ? { group: req.params.chatId }
      : { $or:[{ sender:req.user._id, receiver:req.params.chatId },{ sender:req.params.chatId, receiver:req.user._id }] };
    const msgs = await Message.find({
      ...chatFilter,
      type: { $in:['image','video','document','audio','gif'] },
      deletedFor: { $ne: req.user._id },
      deletedForEveryone: false
    }).sort({ createdAt: -1 }).limit(200);
    res.json(msgs);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/messages/:chatId ────────────────────────
router.get('/:chatId', auth, async (req, res) => {
  try {
    const { chatType, before, limit = 50 } = req.query;
    const chatFilter = chatType === 'group'
      ? { group: req.params.chatId }
      : { $or:[{ sender:req.user._id, receiver:req.params.chatId },{ sender:req.params.chatId, receiver:req.user._id }] };
    const filter = { ...chatFilter, deletedFor:{ $ne:req.user._id } };
    if (before) filter.createdAt = { $lt: new Date(before) };

    const msgs = await populate(Message.find(filter)).sort({ createdAt: -1 }).limit(parseInt(limit));
    msgs.reverse();

    // Mark as read
    if (chatType !== 'group') {
      await Message.updateMany(
        { sender:req.params.chatId, receiver:req.user._id, readBy:{ $ne:req.user._id } },
        { $addToSet:{ readBy:req.user._id } }
      );
    }
    res.json(msgs);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/messages/send ──────────────────────────
router.post('/send', auth, async (req, res) => {
  try {
    const { receiver, group, type, content, sticker, replyTo, scheduledAt, isForwarded, forwardedFrom, poll, gifUrl } = req.body;

    const msgData = {
      sender: req.user._id,
      receiver: receiver || null,
      group: group || null,
      type: type || 'text',
      content: content || '',
      sticker, replyTo, gifUrl,
      isForwarded: !!isForwarded,
      forwardedFrom: forwardedFrom || null,
      isSent: !scheduledAt
    };

    if (scheduledAt) msgData.scheduledAt = new Date(scheduledAt);

    // Poll
    if (type === 'poll' && poll) {
      msgData.poll = {
        question: poll.question,
        options: poll.options.map(o => ({ text: o, votes: [] })),
        multipleChoice: poll.multipleChoice || false,
        anonymous: poll.anonymous || false
      };
    }

    // Link preview for text messages
    if (type === 'text' && content) {
      const url = detectLinks(content);
      if (url) {
        const preview = await fetchLinkPreview(url);
        if (preview) { msgData.type = 'link'; msgData.linkPreview = preview; }
      }
    }

    const message = new Message(msgData);
    await message.save();
    await populate(Message.findById(message._id)).then(m => {
      message.__populated = m;
    });
    const saved = await populate(Message.findById(message._id));
    res.status(201).json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/messages/upload ────────────────────────
router.post('/upload', auth, upload.single('file'), async (req, res) => {
  try {
    const { receiver, group, type, content, replyTo } = req.body;

    let mediaUrl = '', mediaName = req.file.originalname, mediaSize = req.file.size;

    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_CLOUD_NAME !== 'your_cloud_name') {
      let resourceType = 'auto';
      if (type === 'image') resourceType = 'image';
      else if (type === 'video') resourceType = 'video';
      else resourceType = 'raw';

      const result = await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { folder:`nexchat/media/${type}s`, resource_type: resourceType },
          (err, r) => err ? reject(err) : resolve(r)
        );
        stream.end(req.file.buffer);
      });
      mediaUrl = result.secure_url;
    } else {
      // Dev fallback: base64 data URL
      const b64 = req.file.buffer.toString('base64');
      mediaUrl = `data:${req.file.mimetype};base64,${b64}`;
    }

    const message = new Message({
      sender: req.user._id,
      receiver: receiver || null,
      group: group || null,
      type: type || 'document',
      content: content || '',
      mediaUrl, mediaName, mediaSize,
      replyTo: replyTo || null
    });
    await message.save();
    const saved = await populate(Message.findById(message._id));
    res.status(201).json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/messages/:messageId/edit ────────────────
router.put('/:messageId/edit', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const message = await Message.findById(req.params.messageId);
    if (!message) return res.status(404).json({ message:'Not found' });
    if (!message.sender.equals(req.user._id)) return res.status(403).json({ message:'Forbidden' });
    if (message.deletedForEveryone) return res.status(400).json({ message:'Cannot edit deleted message' });

    message.editHistory.push({ content: message.content, editedAt: new Date() });
    message.content  = content;
    message.isEdited = true;
    await message.save();
    const saved = await populate(Message.findById(message._id));
    res.json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/messages/:messageId/react ─────────────
router.post('/:messageId/react', auth, async (req, res) => {
  try {
    const { emoji } = req.body;
    const message = await Message.findById(req.params.messageId);
    if (!message) return res.status(404).json({ message:'Not found' });

    const existing = message.reactions.find(r => r.user.equals(req.user._id));
    if (existing) {
      if (existing.emoji === emoji) {
        // Toggle off
        message.reactions = message.reactions.filter(r => !r.user.equals(req.user._id));
      } else {
        existing.emoji = emoji;
      }
    } else {
      message.reactions.push({ user: req.user._id, emoji });
    }
    await message.save();
    res.json({ reactions: message.reactions });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/messages/:messageId/star ───────────────
router.post('/:messageId/star', auth, async (req, res) => {
  try {
    const message = await Message.findById(req.params.messageId);
    if (!message) return res.status(404).json({ message:'Not found' });
    const starred = message.starredBy.some(id => id.equals(req.user._id));
    if (starred) {
      message.starredBy = message.starredBy.filter(id => !id.equals(req.user._id));
    } else {
      message.starredBy.push(req.user._id);
    }
    await message.save();
    res.json({ starred: !starred });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/messages/:messageId/vote ───────────────
router.post('/:messageId/vote', auth, async (req, res) => {
  try {
    const { optionIndex } = req.body;
    const message = await Message.findById(req.params.messageId);
    if (!message || message.type !== 'poll') return res.status(404).json({ message:'Not found' });

    const opt = message.poll.options[optionIndex];
    if (!opt) return res.status(400).json({ message:'Invalid option' });

    const hasVoted = opt.votes.some(id => id.equals(req.user._id));
    if (hasVoted) {
      opt.votes = opt.votes.filter(id => !id.equals(req.user._id));
    } else {
      if (!message.poll.multipleChoice) {
        // Remove from all other options
        message.poll.options.forEach((o, i) => {
          if (i !== optionIndex) o.votes = o.votes.filter(id => !id.equals(req.user._id));
        });
      }
      opt.votes.push(req.user._id);
    }
    await message.save();
    res.json(message.poll);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── DELETE /api/messages/:messageId ─────────────────
router.delete('/:messageId', auth, async (req, res) => {
  try {
    const { deleteType } = req.body;
    const message = await Message.findById(req.params.messageId);
    if (!message) return res.status(404).json({ message:'Not found' });

    if (deleteType === 'everyone') {
      if (!message.sender.equals(req.user._id)) return res.status(403).json({ message:'Forbidden' });
      message.deletedForEveryone = true;
      message.content  = 'This message was deleted';
      message.mediaUrl = '';
    } else {
      if (!message.deletedFor.some(id => id.equals(req.user._id))) {
        message.deletedFor.push(req.user._id);
      }
    }
    await message.save();
    res.json({ messageId: req.params.messageId, deleteType });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
