const express  = require('express');
const router   = express.Router();
const auth     = require('../middleware/auth');
const Group    = require('../models/Group');
const Message  = require('../models/Message');
const crypto   = require('crypto');
const multer   = require('multer');
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

const upload = multer({ storage: multer.memoryStorage(), limits:{ fileSize:10*1024*1024 } });

const populateGroup = q => q.populate('members.user','name avatar phone').populate('admin','name avatar');

// ── POST /api/groups (create) ────────────────────────
router.post(['/', '/create'], auth, async (req, res) => {
  try {
    const { name, description, members } = req.body;
    const memberObjs = [
      { user: req.user._id, role: 'admin' },
      ...(members||[]).map(id => ({ user: id, role: 'member' }))
    ];
    const inviteLink = crypto.randomBytes(8).toString('hex');
    const group = new Group({ name, description, admin: req.user._id, members: memberObjs, inviteLink });
    await group.save();
    const saved = await populateGroup(Group.findById(group._id));
    res.status(201).json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/groups ──────────────────────────────────
router.get('/', auth, async (req, res) => {
  try {
    const groups = await populateGroup(Group.find({ 'members.user': req.user._id }));
    res.json(groups);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/groups/invite/:link ─────────────────────
router.get('/invite/:link', auth, async (req, res) => {
  try {
    const group = await populateGroup(Group.findOne({ inviteLink: req.params.link }));
    if (!group) return res.status(404).json({ message:'Invite link invalid or expired' });
    res.json(group);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/groups/join/:link ──────────────────────
router.post('/join/:link', auth, async (req, res) => {
  try {
    const group = await Group.findOne({ inviteLink: req.params.link });
    if (!group) return res.status(404).json({ message:'Invalid invite link' });
    const already = group.members.some(m => m.user.equals(req.user._id));
    if (!already) {
      group.members.push({ user: req.user._id, role: 'member' });
      await group.save();
    }
    const saved = await populateGroup(Group.findById(group._id));
    res.json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── GET /api/groups/:groupId ─────────────────────────
router.get('/:groupId', auth, async (req, res) => {
  try {
    const group = await populateGroup(Group.findById(req.params.groupId));
    if (!group) return res.status(404).json({ message:'Not found' });
    res.json(group);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/groups/:groupId ─────────────────────────
router.put('/:groupId', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message:'Not found' });
    const myRole = group.members.find(m => m.user.equals(req.user._id))?.role;
    if (!['admin','moderator'].includes(myRole)) return res.status(403).json({ message:'No permission' });
    const { name, description, isAnnouncement, disappearingMessages } = req.body;
    if (name) group.name = name;
    if (description !== undefined) group.description = description;
    if (isAnnouncement !== undefined) group.isAnnouncement = isAnnouncement;
    if (disappearingMessages !== undefined) group.disappearingMessages = disappearingMessages;
    await group.save();
    const saved = await populateGroup(Group.findById(group._id));
    res.json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/groups/:groupId/avatar ─────────────────
router.post('/:groupId/avatar', auth, upload.single('avatar'), async (req, res) => {
  try {
    let avatarUrl = '';
    if (process.env.CLOUDINARY_CLOUD_NAME && process.env.CLOUDINARY_CLOUD_NAME !== 'your_cloud_name') {
      const result = await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream({ folder:'nexchat/groups', resource_type:'image' }, (err, r) => err ? reject(err) : resolve(r));
        stream.end(req.file.buffer);
      });
      avatarUrl = result.secure_url;
    } else {
      avatarUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    }
    const group = await Group.findByIdAndUpdate(req.params.groupId, { avatar: avatarUrl }, { new:true });
    res.json({ avatar: avatarUrl, group });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── PUT /api/groups/:groupId/members/:userId/role ────
router.put('/:groupId/members/:userId/role', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group.admin.equals(req.user._id)) return res.status(403).json({ message:'Only admin can change roles' });
    const member = group.members.find(m => m.user.equals(req.params.userId));
    if (!member) return res.status(404).json({ message:'Member not found' });
    member.role = req.body.role;
    await group.save();
    res.json({ message:'Role updated' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/groups/:groupId/members ────────────────
router.post('/:groupId/members', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    const myRole = group.members.find(m => m.user.equals(req.user._id))?.role;
    if (!['admin','moderator'].includes(myRole)) return res.status(403).json({ message:'No permission' });
    const { userId } = req.body;
    if (!group.members.some(m => m.user.equals(userId))) {
      group.members.push({ user: userId, role: 'member' });
      await group.save();
    }
    const saved = await populateGroup(Group.findById(group._id));
    res.json(saved);
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── DELETE /api/groups/:groupId/members/:userId ──────
router.delete('/:groupId/members/:userId', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group.admin.equals(req.user._id)) return res.status(403).json({ message:'Only admin can remove members' });
    group.members = group.members.filter(m => !m.user.equals(req.params.userId));
    await group.save();
    res.json({ message:'Member removed' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── DELETE /api/groups/:groupId/leave ────────────────
router.delete('/:groupId/leave', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    group.members = group.members.filter(m => !m.user.equals(req.user._id));
    if (group.members.length === 0) {
      await group.deleteOne();
    } else if (group.admin.equals(req.user._id)) {
      // Promote first admin/mod or first member
      const next = group.members.find(m => m.role === 'admin' || m.role === 'moderator') || group.members[0];
      if (next) { group.admin = next.user; next.role = 'admin'; }
      await group.save();
    } else {
      await group.save();
    }
    res.json({ message:'Left group' });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

// ── POST /api/groups/:groupId/regenerate-invite ──────
router.post('/:groupId/regenerate-invite', auth, async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group.admin.equals(req.user._id)) return res.status(403).json({ message:'Only admin' });
    group.inviteLink = require('crypto').randomBytes(8).toString('hex');
    await group.save();
    res.json({ inviteLink: group.inviteLink });
  } catch (e) { res.status(500).json({ message: e.message }); }
});

module.exports = router;
