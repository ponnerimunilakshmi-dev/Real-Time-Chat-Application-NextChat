const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');

// Calls are handled via Socket.io WebRTC signaling
// This route stores call history if needed
const callSchema = {
  calls: []
};

router.get('/history', auth, async (req, res) => {
  res.json({ calls: [] });
});

module.exports = router;
