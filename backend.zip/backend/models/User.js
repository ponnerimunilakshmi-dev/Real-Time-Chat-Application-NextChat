const mongoose = require('mongoose');

const privacySchema = new mongoose.Schema({
  lastSeen:      { type: String, enum: ['everyone','contacts','nobody'], default: 'everyone' },
  profilePhoto:  { type: String, enum: ['everyone','contacts','nobody'], default: 'everyone' },
  about:         { type: String, enum: ['everyone','contacts','nobody'], default: 'everyone' },
  readReceipts:  { type: Boolean, default: true },
  onlineStatus:  { type: String, enum: ['everyone','contacts','nobody'], default: 'everyone' }
}, { _id: false });

const callLogSchema = new mongoose.Schema({
  peer:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  callType:  { type: String, enum: ['audio','video'], default: 'audio' },
  direction: { type: String, enum: ['incoming','outgoing','missed'], default: 'outgoing' },
  duration:  { type: Number, default: 0 },
  startedAt: { type: Date, default: Date.now }
}, { _id: true });

const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  phone:    { type: String, required: true, unique: true },
  username: { type: String, unique: true, sparse: true, trim: true, lowercase: true },
  password: { type: String, required: true },
  avatar:   { type: String, default: '' },
  about:    { type: String, default: 'Hey there! I am using NexChat.' },

  contacts:     [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  blockedUsers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  theme: {
    type:        { type: String, enum: ['preset','custom'], default: 'preset' },
    value:       { type: String, default: 'dark' },
    bubbleColor: { type: String, default: '#00b4d8' }
  },

  privacy: { type: privacySchema, default: () => ({}) },
  callLog:  [callLogSchema],

  // 2FA
  twoFA: {
    enabled: { type: Boolean, default: false },
    pin:     { type: String, default: '' }  // hashed
  },

  // Disappearing messages default
  disappearingMessages: { type: Number, default: 0 }, // seconds, 0 = off

  isOnline:   { type: Boolean, default: false },
  lastSeen:   { type: Date, default: Date.now },
  otp:        { type: String },
  otpExpiry:  { type: Date },
  isVerified: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
