const mongoose = require('mongoose');

const reactionSchema = new mongoose.Schema({
  user:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  emoji: { type: String, required: true }
}, { _id: false });

const pollOptionSchema = new mongoose.Schema({
  text:  { type: String, required: true },
  votes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
});

const messageSchema = new mongoose.Schema({
  sender:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  receiver: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  group:    { type: mongoose.Schema.Types.ObjectId, ref: 'Group' },

  type: {
    type: String,
    enum: ['text','image','video','audio','document','sticker','emoji','poll','gif','link'],
    default: 'text'
  },

  content:   { type: String, default: '' },
  mediaUrl:  { type: String, default: '' },
  mediaName: { type: String, default: '' },
  mediaSize: { type: Number, default: 0 },
  sticker:   { type: String, default: '' },
  gifUrl:    { type: String, default: '' },

  linkPreview: {
    url:         { type: String, default: '' },
    title:       { type: String, default: '' },
    description: { type: String, default: '' },
    image:       { type: String, default: '' },
    domain:      { type: String, default: '' }
  },

  poll: {
    question:       { type: String, default: '' },
    options:        [pollOptionSchema],
    multipleChoice: { type: Boolean, default: false },
    anonymous:      { type: Boolean, default: false }
  },

  replyTo:       { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },
  isForwarded:   { type: Boolean, default: false },
  forwardedFrom: { type: mongoose.Schema.Types.ObjectId, ref: 'Message' },

  isEdited:    { type: Boolean, default: false },
  editHistory: [{ content: String, editedAt: Date }],

  scheduledAt: { type: Date },
  isSent:      { type: Boolean, default: true },

  deletedFor:         [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  deletedForEveryone: { type: Boolean, default: false },

  reactions: [reactionSchema],

  readBy:      [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  deliveredTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  starredBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  expiresAt: { type: Date }
}, { timestamps: true });

messageSchema.index({ sender: 1, receiver: 1, createdAt: -1 });
messageSchema.index({ group: 1, createdAt: -1 });
messageSchema.index({ scheduledAt: 1, isSent: 1 });
messageSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('Message', messageSchema);
