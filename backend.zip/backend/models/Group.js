const mongoose = require('mongoose');

const memberSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  role: { type: String, enum: ['admin','moderator','member'], default: 'member' },
  addedAt: { type: Date, default: Date.now },
  canSend: { type: Boolean, default: true }
}, { _id: false });

const groupSchema = new mongoose.Schema({
  name:        { type: String, required: true },
  description: { type: String, default: '' },
  avatar:      { type: String, default: '' },
  admin:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  members: [memberSchema],

  inviteLink:    { type: String, unique: true, sparse: true },
  isAnnouncement: { type: Boolean, default: false }, // only admins/mods can send

  disappearingMessages: { type: Number, default: 0 }, // seconds, 0 = off

  clearedBy: [{
    user:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    clearedAt: { type: Date }
  }]
}, { timestamps: true });

module.exports = mongoose.model('Group', groupSchema);
