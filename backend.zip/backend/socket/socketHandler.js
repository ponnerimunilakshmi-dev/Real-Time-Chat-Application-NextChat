const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const Message = require('../models/Message');
const Group   = require('../models/Group');

const onlineUsers = new Map(); // userId -> Set of socketIds (multi-device)

module.exports = (io) => {
  // ── Auth middleware ──
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token;
      if (!token) return next(new Error('No token'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.userId = decoded.userId;
      next();
    } catch { next(new Error('Auth error')); }
  });

  io.on('connection', async (socket) => {
    const uid = socket.userId;
    console.log(`🟢 Connected: ${uid}`);

    // Track socket (multi-device support)
    if (!onlineUsers.has(uid)) onlineUsers.set(uid, new Set());
    onlineUsers.get(uid).add(socket.id);

    await User.findByIdAndUpdate(uid, { isOnline: true, lastSeen: new Date() });
    io.emit('user:online', { userId: uid });

    socket.join(uid);

    // Join all group rooms
    const groups = await Group.find({ 'members.user': uid }).select('_id');
    groups.forEach(g => socket.join(g._id.toString()));

    // ═════════════ MESSAGING ═════════════
    socket.on('message:send', async (data) => {
      try {
        const { receiver, group, type, content, sticker, replyTo, tempId, gifUrl,
                isForwarded, forwardedFrom, poll, scheduledAt, mediaUrl, mediaName, mediaSize } = data;

        // Scheduled? Don't broadcast yet
        if (scheduledAt && new Date(scheduledAt) > new Date()) {
          const msg = new Message({
            sender: uid, receiver: receiver||null, group: group||null,
            type, content, sticker, replyTo, gifUrl, isForwarded, forwardedFrom, poll,
            mediaUrl, mediaName, mediaSize, scheduledAt: new Date(scheduledAt), isSent: false
          });
          await msg.save();
          socket.emit('message:scheduled', { ...msg.toObject(), tempId });
          return;
        }

        const msg = new Message({
          sender: uid, receiver: receiver||null, group: group||null,
          type: type||'text', content, sticker, replyTo, gifUrl,
          isForwarded: !!isForwarded, forwardedFrom: forwardedFrom||null,
          mediaUrl: mediaUrl||'', mediaName: mediaName||'', mediaSize: mediaSize||0
        });

        // Poll
        if (type === 'poll' && poll) {
          msg.poll = { question: poll.question, options: poll.options.map(o=>({ text:o, votes:[] })), multipleChoice: !!poll.multipleChoice };
        }

        // Disappearing messages
        if (receiver) {
          const senderUser = await User.findById(uid);
          if (senderUser.disappearingMessages > 0) {
            msg.expiresAt = new Date(Date.now() + senderUser.disappearingMessages * 1000);
          }
        }
        if (group) {
          const grp = await Group.findById(group);
          if (grp?.disappearingMessages > 0) {
            msg.expiresAt = new Date(Date.now() + grp.disappearingMessages * 1000);
          }
        }

        await msg.save();
        await msg.populate('sender', 'name avatar');
        if (replyTo) await msg.populate('replyTo');

        const payload = { ...msg.toObject(), tempId };

        socket.emit('message:sent', payload);
        if (receiver) io.to(receiver).emit('message:receive', payload);
        if (group)    socket.to(group).emit('message:receive', payload);

      } catch (e) { socket.emit('error', { message: e.message }); }
    });

    socket.on('message:edit', async ({ messageId, content }) => {
      try {
        const msg = await Message.findById(messageId);
        if (!msg || !msg.sender.equals(uid)) return;
        msg.editHistory.push({ content: msg.content, editedAt: new Date() });
        msg.content  = content;
        msg.isEdited = true;
        await msg.save();
        const target = msg.receiver?.toString() || msg.group?.toString();
        const payload = { messageId, content, isEdited: true };
        socket.emit('message:edited', payload);
        if (target) io.to(target).emit('message:edited', payload);
      } catch (e) { socket.emit('error', { message: e.message }); }
    });

    socket.on('message:react', async ({ messageId, emoji }) => {
      try {
        const msg = await Message.findById(messageId);
        if (!msg) return;
        const existing = msg.reactions.find(r => r.user.equals(uid));
        if (existing) {
          if (existing.emoji === emoji) msg.reactions = msg.reactions.filter(r => !r.user.equals(uid));
          else existing.emoji = emoji;
        } else {
          msg.reactions.push({ user: uid, emoji });
        }
        await msg.save();
        const target = msg.receiver?.toString() || msg.group?.toString();
        const payload = { messageId, reactions: msg.reactions, reactedBy: uid };
        socket.emit('message:reacted', payload);
        if (target) io.to(target).emit('message:reacted', payload);
      } catch (e) { socket.emit('error', { message: e.message }); }
    });

    socket.on('message:star', async ({ messageId }) => {
      try {
        const msg = await Message.findById(messageId);
        if (!msg) return;
        const starred = msg.starredBy.some(id => id.equals(uid));
        if (starred) msg.starredBy = msg.starredBy.filter(id => !id.equals(uid));
        else msg.starredBy.push(uid);
        await msg.save();
        socket.emit('message:starred', { messageId, starred: !starred });
      } catch (e) {}
    });

    socket.on('message:delete', async ({ messageId, deleteType }) => {
      try {
        const msg = await Message.findById(messageId);
        if (!msg) return;
        if (deleteType === 'everyone' && msg.sender.equals(uid)) {
          msg.deletedForEveryone = true;
          msg.content = 'This message was deleted';
          msg.mediaUrl = '';
        } else {
          if (!msg.deletedFor.some(id => id.equals(uid))) msg.deletedFor.push(uid);
        }
        await msg.save();
        const target = msg.receiver?.toString() || msg.group?.toString();
        const payload = { messageId, deleteType };
        socket.emit('message:deleted', payload);
        if (deleteType === 'everyone' && target) io.to(target).emit('message:deleted', payload);
      } catch (e) {}
    });

    socket.on('message:read', async ({ messageId, senderId }) => {
      const msg = await Message.findByIdAndUpdate(messageId, { $addToSet:{ readBy: uid } });
      io.to(senderId).emit('message:read', { messageId, readBy: uid });
    });

    socket.on('poll:vote', async ({ messageId, optionIndex }) => {
      try {
        const msg = await Message.findById(messageId);
        if (!msg || msg.type !== 'poll') return;
        const opt = msg.poll.options[optionIndex];
        if (!opt) return;
        const hasVoted = opt.votes.some(id => id.equals(uid));
        if (hasVoted) opt.votes = opt.votes.filter(id => !id.equals(uid));
        else {
          if (!msg.poll.multipleChoice) msg.poll.options.forEach((o, i) => { if (i !== optionIndex) o.votes = o.votes.filter(id => !id.equals(uid)); });
          opt.votes.push(uid);
        }
        await msg.save();
        const target = msg.receiver?.toString() || msg.group?.toString();
        const payload = { messageId, poll: msg.poll };
        socket.emit('poll:updated', payload);
        if (target) io.to(target).emit('poll:updated', payload);
      } catch (e) {}
    });

    // ═════════════ TYPING ═════════════
    socket.on('typing:start', ({ to }) => io.to(to).emit('typing:start', { from: uid }));
    socket.on('typing:stop',  ({ to }) => io.to(to).emit('typing:stop',  { from: uid }));

    // ═════════════ GROUPS ═════════════
    socket.on('group:join',  ({ groupId }) => socket.join(groupId));
    socket.on('group:leave', ({ groupId }) => socket.leave(groupId));

    // ═════════════ CALLS (WebRTC) ═════════════
    socket.on('call:initiate', async ({ to, callType, offer, isGroup, groupId }) => {
      if (isGroup && groupId) {
        // Group call — notify all group members
        socket.to(groupId).emit('call:incoming', { from: uid, callType, offer, isGroup: true, groupId });
      } else {
        io.to(to).emit('call:incoming', { from: uid, callType, offer });
      }
    });

    socket.on('call:answer',        ({ to, answer })    => io.to(to).emit('call:answered',   { answer, from: uid }));
    socket.on('call:ice-candidate', ({ to, candidate }) => io.to(to).emit('call:ice-candidate', { candidate, from: uid }));
    socket.on('call:end',           ({ to })            => io.to(to).emit('call:ended',       { from: uid }));
    socket.on('call:reject',        ({ to })            => io.to(to).emit('call:rejected',    { from: uid }));
    socket.on('call:screen-share',  ({ to, enabled })   => io.to(to).emit('call:screen-share', { from: uid, enabled }));

    socket.on('call:log', async ({ peer, callType, direction, duration }) => {
      try {
        await User.findByIdAndUpdate(uid, {
          $push: { callLog: { peer, callType, direction: direction||'outgoing', duration: duration||0, startedAt: new Date() } }
        });
      } catch (e) {}
    });

    // ═════════════ DISCONNECT ═════════════
    socket.on('disconnect', async () => {
      const sockets = onlineUsers.get(uid);
      if (sockets) {
        sockets.delete(socket.id);
        if (sockets.size === 0) {
          onlineUsers.delete(uid);
          await User.findByIdAndUpdate(uid, { isOnline: false, lastSeen: new Date() });
          io.emit('user:offline', { userId: uid, lastSeen: new Date() });
          console.log(`🔴 Disconnected: ${uid}`);
        }
      }
    });
  });

  // ═════════════ SCHEDULED MESSAGE DISPATCHER ═════════════
  setInterval(async () => {
    try {
      const now = new Date();
      const due = await Message.find({ isSent: false, scheduledAt: { $lte: now } })
        .populate('sender','name avatar');
      for (const msg of due) {
        msg.isSent = true;
        await msg.save();
        const payload = msg.toObject();
        const receiver = msg.receiver?.toString();
        const group    = msg.group?.toString();
        if (receiver) {
          io.to(msg.sender._id.toString()).emit('message:sent',    payload);
          io.to(receiver).emit('message:receive', payload);
        }
        if (group) {
          io.to(msg.sender._id.toString()).emit('message:sent',    payload);
          io.to(group).emit('message:receive', payload);
        }
      }
    } catch (e) { console.error('Scheduler error:', e.message); }
  }, 10000); // every 10s
};
